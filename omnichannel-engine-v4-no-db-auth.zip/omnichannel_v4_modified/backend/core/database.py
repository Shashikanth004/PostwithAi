from motor.motor_asyncio import AsyncIOMotorClient
from .config import settings

client: AsyncIOMotorClient = None


async def connect_db():
    global client
    try:
        client = AsyncIOMotorClient(settings.MONGODB_URL, serverSelectionTimeoutMS=3000)
        # Ping to verify connection
        await client.admin.command("ping")
        print(f"✅ MongoDB connected: {settings.MONGODB_URL}")
    except Exception as e:
        print(f"⚠️  MongoDB not available ({e}). Social accounts / posts features disabled.")
        client = None


async def close_db():
    global client
    if client:
        client.close()


def get_db():
    if client is None:
        return None
    return client[settings.MONGODB_DB]


# ── Collection accessors ─────────────────────────────────────────────────────
# users_col removed — user identity now lives entirely in the JWT

def social_accounts_col():
    db = get_db()
    return db["social_accounts"] if db is not None else None


def scheduled_posts_col():
    db = get_db()
    return db["scheduled_posts"] if db is not None else None


def orchestration_history_col():
    db = get_db()
    return db["orchestration_history"] if db is not None else None
