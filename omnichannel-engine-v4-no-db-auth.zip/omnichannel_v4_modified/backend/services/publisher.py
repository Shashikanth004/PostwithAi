"""
Publishing dispatcher.
Given a platform name, a generated payload dict, and optional media URL,
calls the correct posting service and returns a standardised result.
"""
from .post_linkedin  import post_text         as linkedin_post
from .post_x         import post_text         as x_post
from .post_meta      import post_instagram, post_facebook
from .post_tiktok    import post_video        as tiktok_post_video, post_text_caption as tiktok_post_text
from .post_pinterest import post_pin          as pinterest_post
from .post_youtube   import post_video        as youtube_post


async def dispatch(
    user_id: str,
    platform: str,
    payload: dict,
    media_url: str = None,
) -> dict:
    """
    Dispatch a post to the correct platform service.

    Args:
        user_id:   The app user's google_id (used to look up stored tokens)
        platform:  Platform key e.g. "linkedin", "x", "tiktok" ...
        payload:   The platform entry from scheduled_payload (caption, hashtags, hook, thread_tweets...)
        media_url: Optional publicly accessible URL to an uploaded image/video

    Returns:
        A dict with at minimum: { platform, status, ... }
    """
    caption   = payload.get("caption", "")
    hook      = payload.get("hook", "")
    hashtags  = payload.get("hashtags", [])
    threads   = payload.get("thread_tweets", [])
    fmt       = payload.get("format", "text")

    # Use hook as opening line if available, prepend to caption
    full_text = f"{hook}\n\n{caption}".strip() if hook and hook not in caption else caption

    try:
        if platform == "linkedin":
            return await linkedin_post(user_id, full_text, hashtags)

        elif platform == "x":
            return await x_post(user_id, full_text, hashtags, thread_tweets=threads)

        elif platform in ("instagram", "instagram_reels"):
            return await post_instagram(user_id, full_text, image_url=media_url, hashtags=hashtags)

        elif platform == "facebook":
            return await post_facebook(user_id, full_text, hashtags=hashtags, image_url=media_url)

        elif platform == "tiktok":
            if media_url and (media_url.endswith(".mp4") or media_url.endswith(".mov") or media_url.endswith(".webm")):
                return await tiktok_post_video(user_id, full_text, video_url=media_url, hashtags=hashtags)
            else:
                return await tiktok_post_text(user_id, full_text, hashtags=hashtags)

        elif platform == "pinterest":
            title = payload.get("hook", caption[:100])
            return await pinterest_post(user_id, title, caption, image_url=media_url, hashtags=hashtags)

        elif platform in ("youtube", "youtube_shorts"):
            title = payload.get("hook", caption[:100])
            return await youtube_post(user_id, title, full_text, video_url=media_url, hashtags=hashtags)

        elif platform == "threads":
            # Threads uses Instagram API in newer versions — treat same as instagram text
            return await post_instagram(user_id, full_text, image_url=media_url, hashtags=hashtags)

        else:
            return {
                "platform": platform,
                "status": "unsupported",
                "reason": f"Direct posting for '{platform}' is not yet implemented.",
            }

    except ValueError as e:
        return {"platform": platform, "status": "error", "error": str(e)}
    except RuntimeError as e:
        return {"platform": platform, "status": "error", "error": str(e)}
    except Exception as e:
        return {"platform": platform, "status": "error", "error": f"Unexpected error: {str(e)}"}
