"""
YouTube posting service.
Uploads videos to YouTube using the YouTube Data API v3.
API docs: https://developers.google.com/youtube/v3/docs/videos/insert
"""
import httpx
import json
from .token_service import get_valid_token

YOUTUBE_UPLOAD_API = "https://www.googleapis.com/upload/youtube/v3/videos"
YOUTUBE_API = "https://www.googleapis.com/youtube/v3"


async def post_video(
    user_id: str,
    title: str,
    description: str,
    video_url: str = None,
    hashtags: list = None,
    privacy: str = "public",
) -> dict:
    """
    Upload a video to YouTube.
    video_url must be a publicly accessible URL to an MP4 file (fetched server-side).
    """
    token = await get_valid_token(user_id, "youtube")

    tags = [tag.lstrip("#") for tag in (hashtags or [])]
    full_description = description
    if hashtags:
        full_description += "\n\n" + " ".join(hashtags)

    if not video_url:
        return {
            "platform": "youtube",
            "status": "skipped",
            "reason": "YouTube requires a video file. Upload a video and provide its public URL.",
            "title_ready": title,
            "description_ready": full_description,
            "tags_ready": tags,
        }

    # Fetch video bytes from URL
    async with httpx.AsyncClient(timeout=120) as client:
        video_resp = await client.get(video_url)
        if video_resp.status_code != 200:
            raise RuntimeError(f"Could not fetch video from URL: {video_url}")
        video_bytes = video_resp.content

    metadata = {
        "snippet": {
            "title": title[:100],
            "description": full_description[:5000],
            "tags": tags[:500],
            "categoryId": "22",  # People & Blogs default
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        }
    }

    # Multipart upload
    boundary = "omni_boundary_xyz"
    body = (
        f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"
        + json.dumps(metadata)
        + f"\r\n--{boundary}\r\nContent-Type: video/mp4\r\n\r\n"
    ).encode() + video_bytes + f"\r\n--{boundary}--".encode()

    async with httpx.AsyncClient(timeout=300) as client:
        r = await client.post(
            f"{YOUTUBE_UPLOAD_API}?uploadType=multipart&part=snippet,status",
            content=body,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": f"multipart/related; boundary={boundary}",
            }
        )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"YouTube upload failed ({r.status_code}): {r.text}")

    video_id = r.json().get("id", "")
    return {
        "platform": "youtube",
        "status": "published",
        "video_id": video_id,
        "url": f"https://www.youtube.com/watch?v={video_id}",
        "note": "Video is processing — it may take a few minutes to appear publicly.",
    }
