"""
Pinterest posting service.
Creates Pins using the Pinterest API v5.
API docs: https://developers.pinterest.com/docs/api/v5/pins-create
"""
import httpx
from .token_service import get_valid_token

PINTEREST_API = "https://api.pinterest.com/v5"


async def get_default_board(token: str) -> str:
    """Fetch the user's first board ID to pin to."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{PINTEREST_API}/boards",
            headers={"Authorization": f"Bearer {token}"},
            params={"page_size": 1}
        )
        r.raise_for_status()

    boards = r.json().get("items", [])
    if not boards:
        raise RuntimeError("No Pinterest boards found. Create a board first.")
    return boards[0]["id"]


async def post_pin(
    user_id: str,
    title: str,
    description: str,
    image_url: str = None,
    link: str = None,
    hashtags: list = None,
    board_id: str = None,
) -> dict:
    """Create a Pin on Pinterest."""
    token = await get_valid_token(user_id, "pinterest")

    if not board_id:
        board_id = await get_default_board(token)

    full_description = description
    if hashtags:
        full_description += "\n" + " ".join(hashtags)

    if not image_url:
        return {
            "platform": "pinterest",
            "status": "skipped",
            "reason": "Pinterest requires an image to create a Pin. Upload an image first.",
        }

    body = {
        "board_id": board_id,
        "title": title[:100],
        "description": full_description[:500],
        "media_source": {
            "source_type": "image_url",
            "url": image_url,
        },
    }
    if link:
        body["link"] = link

    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{PINTEREST_API}/pins",
            json=body,
            headers={"Authorization": f"Bearer {token}"}
        )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"Pinterest pin failed ({r.status_code}): {r.text}")

    pin_data = r.json()
    pin_id = pin_data.get("id", "")
    return {
        "platform": "pinterest",
        "status": "published",
        "pin_id": pin_id,
        "url": f"https://pinterest.com/pin/{pin_id}/",
    }
