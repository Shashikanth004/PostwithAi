"""
TikTok posting service.
Uses TikTok Content Posting API v2 to publish videos.
API docs: https://developers.tiktok.com/doc/content-posting-api-reference-direct-post
"""
import httpx
from .token_service import get_valid_token

TIKTOK_API = "https://open.tiktokapis.com/v2"


async def post_video(user_id: str, caption: str, video_url: str, hashtags: list = None) -> dict:
    """
    Publish a video to TikTok via Direct Post (URL-based upload).
    video_url must be a publicly accessible URL to an MP4 file.
    """
    token = await get_valid_token(user_id, "tiktok")

    full_caption = caption
    if hashtags:
        # TikTok: hashtags go inline in caption
        full_caption += " " + " ".join(hashtags)

    if not video_url:
        return {
            "platform": "tiktok",
            "status": "skipped",
            "reason": "TikTok requires a video URL to publish. Upload a video and provide its public URL.",
        }

    body = {
        "post_info": {
            "title": full_caption[:2200],  # TikTok max caption length
            "privacy_level": "PUBLIC_TO_EVERYONE",
            "disable_duet": False,
            "disable_stitch": False,
            "disable_comment": False,
        },
        "source_info": {
            "source": "PULL_FROM_URL",
            "video_url": video_url,
        }
    }

    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{TIKTOK_API}/post/publish/video/init/",
            json=body,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json; charset=UTF-8",
            }
        )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"TikTok post failed ({r.status_code}): {r.text}")

    data = r.json().get("data", {})
    publish_id = data.get("publish_id", "")

    return {
        "platform": "tiktok",
        "status": "published",
        "publish_id": publish_id,
        "note": "Video is being processed by TikTok. It will appear in your profile within a few minutes.",
    }


async def post_text_caption(user_id: str, caption: str, hashtags: list = None) -> dict:
    """
    For TikTok, text-only posts are not supported via API.
    Returns a queued status with the caption ready to copy.
    """
    full_caption = caption
    if hashtags:
        full_caption += " " + " ".join(hashtags)

    return {
        "platform": "tiktok",
        "status": "manual_required",
        "caption": full_caption,
        "reason": "TikTok API requires a video. Copy the caption above and post manually.",
    }
