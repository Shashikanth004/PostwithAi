"""
Meta posting service — covers Instagram feed posts and Facebook page posts.
Instagram Graph API: https://developers.facebook.com/docs/instagram-api/guides/content-publishing
Facebook Graph API: https://developers.facebook.com/docs/graph-api/reference/page/feed/
"""
import httpx
from .token_service import get_valid_token

GRAPH_API = "https://graph.facebook.com/v19.0"


async def _get_ig_account_id(token: str) -> str:
    """Get the Instagram Business Account ID linked to the user's Facebook pages."""
    async with httpx.AsyncClient() as client:
        # Get pages
        pages_r = await client.get(f"{GRAPH_API}/me/accounts", params={"access_token": token})
        pages_r.raise_for_status()
        pages = pages_r.json().get("data", [])

        if not pages:
            raise RuntimeError("No Facebook Pages found. Connect a page with Instagram linked.")

        page = pages[0]
        page_token = page.get("access_token", token)
        page_id = page["id"]

        # Get Instagram account linked to this page
        ig_r = await client.get(
            f"{GRAPH_API}/{page_id}",
            params={"fields": "instagram_business_account", "access_token": page_token}
        )
        ig_r.raise_for_status()
        ig_data = ig_r.json().get("instagram_business_account", {})
        ig_id = ig_data.get("id")

        if not ig_id:
            raise RuntimeError("No Instagram Business account linked to your Facebook Page.")

        return ig_id, page_token, page_id


async def post_instagram(user_id: str, caption: str, image_url: str = None, hashtags: list = None) -> dict:
    """
    Publish a post to Instagram.
    If image_url is provided, creates an image post. Otherwise, requires image_url
    (Instagram does not support text-only posts via API — image is mandatory).
    """
    token = await get_valid_token(user_id, "instagram")
    ig_account_id, page_token, _ = await _get_ig_account_id(token)

    full_caption = caption
    if hashtags:
        full_caption += "\n\n" + " ".join(hashtags)

    if not image_url:
        return {
            "platform": "instagram",
            "status": "skipped",
            "reason": "Instagram requires an image URL to publish. Upload a media file and include its URL.",
        }

    async with httpx.AsyncClient() as client:
        # Step 1: Create media container
        container_r = await client.post(
            f"{GRAPH_API}/{ig_account_id}/media",
            params={
                "image_url": image_url,
                "caption": full_caption,
                "access_token": page_token,
            }
        )
        container_r.raise_for_status()
        container_id = container_r.json().get("id")

        # Step 2: Publish the container
        publish_r = await client.post(
            f"{GRAPH_API}/{ig_account_id}/media_publish",
            params={"creation_id": container_id, "access_token": page_token}
        )
        publish_r.raise_for_status()
        post_id = publish_r.json().get("id", "")

    return {
        "platform": "instagram",
        "status": "published",
        "post_id": post_id,
        "url": f"https://www.instagram.com/p/{post_id}/",
    }


async def post_facebook(user_id: str, message: str, hashtags: list = None, image_url: str = None) -> dict:
    """Post a text (+ optional image) update to the user's Facebook Page."""
    token = await get_valid_token(user_id, "instagram")  # same Meta token
    _, page_token, page_id = await _get_ig_account_id(token)

    full_message = message
    if hashtags:
        full_message += "\n\n" + " ".join(hashtags)

    params = {"message": full_message, "access_token": page_token}
    if image_url:
        params["link"] = image_url

    async with httpx.AsyncClient() as client:
        r = await client.post(f"{GRAPH_API}/{page_id}/feed", params=params)
        r.raise_for_status()

    post_id = r.json().get("id", "")
    return {
        "platform": "facebook",
        "status": "published",
        "post_id": post_id,
        "url": f"https://www.facebook.com/{post_id}",
    }
