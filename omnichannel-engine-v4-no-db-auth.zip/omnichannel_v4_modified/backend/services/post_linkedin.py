"""
LinkedIn posting service.
Publishes text posts (with optional image) to the authenticated user's LinkedIn feed.
API docs: https://learn.microsoft.com/en-us/linkedin/marketing/integrations/community-management/shares/ugc-post-api
"""
import httpx
from .token_service import get_valid_token

LINKEDIN_API = "https://api.linkedin.com/v2"


async def get_profile_urn(access_token: str) -> str:
    """Fetch the LinkedIn member URN (urn:li:person:xxx) needed for posting."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{LINKEDIN_API}/userinfo",
            headers={"Authorization": f"Bearer {access_token}"}
        )
    r.raise_for_status()
    sub = r.json().get("sub", "")
    return f"urn:li:person:{sub}"


async def post_text(user_id: str, text: str, hashtags: list = None) -> dict:
    """Post a text update to LinkedIn feed."""
    token = await get_valid_token(user_id, "linkedin")
    author_urn = await get_profile_urn(token)

    # Append hashtags to text if provided
    full_text = text
    if hashtags:
        full_text += "\n\n" + " ".join(hashtags)

    body = {
        "author": author_urn,
        "lifecycleState": "PUBLISHED",
        "specificContent": {
            "com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": full_text},
                "shareMediaCategory": "NONE",
            }
        },
        "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
    }

    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{LINKEDIN_API}/ugcPosts",
            json=body,
            headers={
                "Authorization": f"Bearer {token}",
                "X-Restli-Protocol-Version": "2.0.0",
            }
        )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"LinkedIn post failed ({r.status_code}): {r.text}")

    post_id = r.headers.get("X-RestLi-Id", r.json().get("id", ""))
    return {
        "platform": "linkedin",
        "status": "published",
        "post_id": post_id,
        "url": f"https://www.linkedin.com/feed/update/{post_id}",
    }
