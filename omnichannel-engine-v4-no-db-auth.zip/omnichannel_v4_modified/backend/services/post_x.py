"""
X (Twitter) posting service.
Posts single tweets or full threads using the Twitter API v2.
API docs: https://developer.twitter.com/en/docs/twitter-api/tweets/manage-tweets/api-reference/post-tweets
"""
import httpx
from .token_service import get_valid_token

X_API = "https://api.twitter.com/2"


async def post_tweet(token: str, text: str, reply_to_id: str = None) -> dict:
    """Post a single tweet, optionally as a reply."""
    body = {"text": text[:280]}
    if reply_to_id:
        body["reply"] = {"in_reply_to_tweet_id": reply_to_id}

    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{X_API}/tweets",
            json=body,
            headers={"Authorization": f"Bearer {token}"}
        )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"X tweet failed ({r.status_code}): {r.text}")

    return r.json().get("data", {})


async def post_text(user_id: str, text: str, hashtags: list = None, thread_tweets: list = None) -> dict:
    """
    Post to X. If thread_tweets is provided, posts as a thread.
    Otherwise posts a single tweet (with hashtags appended).
    """
    token = await get_valid_token(user_id, "x")

    if thread_tweets and len(thread_tweets) > 1:
        # Post as thread — each tweet replies to the previous
        results = []
        last_id = None
        for tweet_text in thread_tweets:
            data = await post_tweet(token, tweet_text[:280], reply_to_id=last_id)
            last_id = data.get("id")
            results.append(data)

        return {
            "platform": "x",
            "status": "published",
            "format": "thread",
            "tweet_count": len(results),
            "first_tweet_id": results[0].get("id") if results else None,
            "url": f"https://x.com/i/web/status/{results[0].get('id')}" if results else None,
        }
    else:
        # Single tweet
        full_text = text
        if hashtags:
            tags = " ".join(hashtags)
            if len(full_text) + len(tags) + 2 <= 280:
                full_text += "\n" + tags

        data = await post_tweet(token, full_text)
        tweet_id = data.get("id", "")
        return {
            "platform": "x",
            "status": "published",
            "tweet_id": tweet_id,
            "url": f"https://x.com/i/web/status/{tweet_id}",
        }
