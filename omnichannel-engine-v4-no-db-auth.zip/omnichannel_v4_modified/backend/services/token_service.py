"""
Token refresh service.
Checks if a stored access_token is close to expiry and refreshes it
using the stored refresh_token. Updates the encrypted token in MongoDB.
"""
import httpx
from datetime import datetime, timedelta
from ..core.database import social_accounts_col
from ..core.security import encrypt_token, decrypt_token

# Platform token refresh endpoints
REFRESH_ENDPOINTS = {
    "linkedin":  "https://www.linkedin.com/oauth/v2/accessToken",
    "x":         "https://api.twitter.com/2/oauth2/token",
    "instagram": "https://graph.facebook.com/v19.0/oauth/access_token",
    "tiktok":    "https://open.tiktokapis.com/v2/oauth/token/",
    "pinterest": "https://api.pinterest.com/v5/oauth/token",
    "youtube":   "https://oauth2.googleapis.com/token",
}


async def get_valid_token(user_id: str, platform: str) -> str:
    """
    Return a valid decrypted access token for user+platform.
    Automatically refreshes if the token is within 5 minutes of expiry.
    Raises ValueError if account not connected or refresh fails.
    """
    account = await social_accounts_col().find_one({"user_id": user_id, "platform": platform})
    if not account:
        raise ValueError(f"No connected {platform} account. Connect it from the Accounts page.")

    if account.get("status") == "expired":
        raise ValueError(f"{platform} token has expired. Please reconnect the account.")

    # Check if we should refresh (if token_expires_at is stored and close)
    expires_at_str = account.get("token_expires_at")
    if expires_at_str:
        expires_at = datetime.fromisoformat(expires_at_str)
        if datetime.utcnow() >= expires_at - timedelta(minutes=5):
            return await _refresh_token(account, platform)

    return decrypt_token(account["access_token"])


async def _refresh_token(account: dict, platform: str) -> str:
    """Exchange refresh_token for a new access_token and update DB."""
    from ..core.config import settings

    refresh_token_enc = account.get("refresh_token", "")
    if not refresh_token_enc:
        raise ValueError(f"{platform} has no refresh token stored. Please reconnect.")

    refresh_token = decrypt_token(refresh_token_enc)

    # Get client credentials per platform
    creds = {
        "linkedin":  (settings.LINKEDIN_CLIENT_ID,  settings.LINKEDIN_CLIENT_SECRET),
        "x":         (settings.X_CLIENT_ID,          settings.X_CLIENT_SECRET),
        "instagram": (settings.META_APP_ID,           settings.META_APP_SECRET),
        "tiktok":    (settings.TIKTOK_CLIENT_KEY,     settings.TIKTOK_CLIENT_SECRET),
        "pinterest": (settings.PINTEREST_APP_ID,      settings.PINTEREST_APP_SECRET),
        "youtube":   (settings.YOUTUBE_CLIENT_ID,     settings.YOUTUBE_CLIENT_SECRET),
    }
    client_id, client_secret = creds.get(platform, ("", ""))

    endpoint = REFRESH_ENDPOINTS.get(platform)
    if not endpoint:
        raise ValueError(f"No refresh endpoint configured for {platform}")

    async with httpx.AsyncClient() as client:
        resp = await client.post(endpoint, data={
            "grant_type":    "refresh_token",
            "refresh_token": refresh_token,
            "client_id":     client_id,
            "client_secret": client_secret,
        })

    if resp.status_code not in (200, 201):
        # Mark account as expired so user knows to reconnect
        await social_accounts_col().update_one(
            {"user_id": account["user_id"], "platform": platform},
            {"$set": {"status": "expired"}}
        )
        raise ValueError(f"{platform} token refresh failed. Please reconnect the account.")

    tokens = resp.json()
    new_access  = tokens.get("access_token", "")
    new_refresh = tokens.get("refresh_token", refresh_token)  # some platforms rotate
    expires_in  = tokens.get("expires_in", 3600)

    expires_at = (datetime.utcnow() + timedelta(seconds=expires_in)).isoformat()

    await social_accounts_col().update_one(
        {"user_id": account["user_id"], "platform": platform},
        {"$set": {
            "access_token":    encrypt_token(new_access),
            "refresh_token":   encrypt_token(new_refresh),
            "token_expires_at": expires_at,
            "last_refreshed":  datetime.utcnow().isoformat(),
            "status":          "active",
        }}
    )

    return new_access
