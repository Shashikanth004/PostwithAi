from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from core.config import settings
from core.database import connect_db, close_db
from routers.auth import router as auth_router
from routers.social_accounts import router as social_router
from routers.orchestration import router as orchestration_router
from routers.posts import router as posts_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_db()
    yield
    await close_db()


app = FastAPI(
    title="Omnichannel Orchestration Engine",
    version="4.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(social_router)
app.include_router(orchestration_router)
app.include_router(posts_router)


@app.get("/platforms")
async def get_platforms():
    return {"platforms": [
        {"id": "tiktok",          "label": "TikTok",          "icon": "🎵", "type": "video",     "color": "#69C9D0"},
        {"id": "instagram_reels", "label": "Instagram Reels", "icon": "📸", "type": "video",     "color": "#E1306C"},
        {"id": "youtube_shorts",  "label": "YouTube Shorts",  "icon": "▶️", "type": "video",     "color": "#FF0000"},
        {"id": "linkedin",        "label": "LinkedIn",        "icon": "💼", "type": "text",      "color": "#0A66C2"},
        {"id": "x",               "label": "X (Twitter)",     "icon": "𝕏",  "type": "thread",    "color": "#e7e9ea"},
        {"id": "threads",         "label": "Threads",         "icon": "🧵", "type": "thread",    "color": "#aaaaaa"},
        {"id": "instagram",       "label": "Instagram",       "icon": "📷", "type": "image",     "color": "#C13584"},
        {"id": "pinterest",       "label": "Pinterest",       "icon": "📌", "type": "visual",    "color": "#E60023"},
        {"id": "facebook",        "label": "Facebook",        "icon": "👥", "type": "community", "color": "#1877F2"},
        {"id": "youtube",         "label": "YouTube",         "icon": "🎬", "type": "video",     "color": "#FF0000"},
    ]}


@app.get("/trends")
async def get_trends():
    return {
        "trending_audio": ["Espresso - Sabrina Carpenter", "original sound - @creator123"],
        "trending_formats": ["POV storytelling", "Before/After reveals", "3-step tutorials"],
        "trending_hashtags": {
            "tiktok":    ["#fyp", "#viral", "#learnontiktok"],
            "instagram": ["#reels", "#explore", "#trending"],
            "linkedin":  ["#leadership", "#innovation", "#growthmindset"],
            "x":         ["#thread", "#buildingpublicly"],
        },
    }


@app.get("/health")
async def health():
    return {"status": "online", "engine": "Omnichannel Orchestration Engine v4.0"}
