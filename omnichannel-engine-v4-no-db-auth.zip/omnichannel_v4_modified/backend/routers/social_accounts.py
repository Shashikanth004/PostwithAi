"""
Social media OAuth connection router.

Each platform follows the same pattern:
  GET /social/{platform}/connect  → redirect to platform OAuth consent
  GET /social/{platform}/callback → exchange code, encrypt & store tokens in MongoDB
  DELETE /social/{platform}       → disconnect / remove stored tokens
  GET /social/accounts            → list all connected accounts for the current user
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from urllib.parse import urlencode
from datetime import datetime
import httpx
import secrets

from ..core.config import settings
from ..core.security import encrypt_token, decrypt_token
from ..core.database import social_accounts_col
from ..core.deps import get_current_user

router = APIRouter(prefix="/social", tags=["social-accounts"])

# ── OAuth configs per platform ────────────────────────────────────────────────

PLATFORM_CONFIGS = {
    "linkedin": {
        "auth_url": "https://www.linkedin.com/oauth/v2/authorization",
        "token_url": "https://www.linkedin.com/oauth/v2/accessToken",
        "profile_url": "https://api.linkedin.com/v2/userinfo",
        "client_id_key": "LINKEDIN_CLIENT_ID",
        "client_secret_key": "LINKEDIN_CLIENT_SECRET",
        "scopes": "openid profile email w_member_social",
        "label": "LinkedIn",
        "icon": "💼",
    },
    "x": {
        "auth_url": "https://twitter.com/i/oauth2/authorize",
        "token_url": "https://api.twitter.com/2/oauth2/token",
        "profile_url": "https://api.twitter.com/2/users/me",
        "client_id_key": "X_CLIENT_ID",
        "client_secret_key": "X_CLIENT_SECRET",
        "scopes": "tweet.read tweet.write users.read offline.access",
        "label": "X (Twitter)",
        "icon": "𝕏",
        "pkce": True,  # X requires PKCE
    },
    "instagram": {
        "auth_url": "https://www.facebook.com/v19.0/dialog/oauth",
        "token_url": "https://graph.facebook.com/v19.0/oauth/access_token",
        "profile_url": "https://graph.facebook.com/me?fields=id,name,email,picture",
        "client_id_key": "META_APP_ID",
        "client_secret_key": "META_APP_SECRET",
        "scopes": "instagram_basic,instagram_content_publish,pages_show_list,pages_read_engagement",
        "label": "Instagram / Facebook",
        "icon": "📸",
    },
    "tiktok": {
        "auth_url": "https://www.tiktok.com/v2/auth/authorize/",
        "token_url": "https://open.tiktokapis.com/v2/oauth/token/",
        "profile_url": "https://open.tiktokapis.com/v2/user/info/",
        "client_id_key": "TIKTOK_CLIENT_KEY",
        "client_secret_key": "TIKTOK_CLIENT_SECRET",
        "scopes": "user.info.basic,video.publish,video.upload",
        "label": "TikTok",
        "icon": "🎵",
    },
    "pinterest": {
        "auth_url": "https://www.pinterest.com/oauth/",
        "token_url": "https://api.pinterest.com/v5/oauth/token",
        "profile_url": "https://api.pinterest.com/v5/user_account",
        "client_id_key": "PINTEREST_APP_ID",
        "client_secret_key": "PINTEREST_APP_SECRET",
        "scopes": "boards:read,pins:read,pins:write,user_accounts:read",
        "label": "Pinterest",
        "icon": "📌",
    },
    "youtube": {
        "auth_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "profile_url": "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
        "client_id_key": "YOUTUBE_CLIENT_ID",
        "client_secret_key": "YOUTUBE_CLIENT_SECRET",
        "scopes": "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly",
        "label": "YouTube",
        "icon": "🎬",
    },
}

# Temporary state store (in production use Redis or DB)
_oauth_states: dict = {}


def _callback_uri(platform: str) -> str:
    return f"{settings.BACKEND_URL}/social/{platform}/callback"


def _get_client_creds(platform: str):
    cfg = PLATFORM_CONFIGS[platform]
    client_id = getattr(settings, cfg["client_id_key"], "")
    client_secret = getattr(settings, cfg["client_secret_key"], "")
    return client_id, client_secret


# ── Connect ───────────────────────────────────────────────────────────────────

@router.get("/{platform}/connect")
async def connect_platform(platform: str, current_user: dict = Depends(get_current_user)):
    if platform not in PLATFORM_CONFIGS:
        raise HTTPException(400, f"Unsupported platform: {platform}")

    cfg = PLATFORM_CONFIGS[platform]
    client_id, _ = _get_client_creds(platform)

    if not client_id:
        raise HTTPException(400, f"{platform} OAuth not configured. Add credentials to .env")

    # Generate state = platform|user_google_id to verify on callback
    state = secrets.token_urlsafe(32)
    _oauth_states[state] = {"platform": platform, "user_id": current_user["google_id"]}

    params = {
        "client_id": client_id,
        "redirect_uri": _callback_uri(platform),
        "response_type": "code",
        "scope": cfg["scopes"],
        "state": state,
        "access_type": "offline",
    }

    # PKCE for X
    if cfg.get("pkce"):
        import hashlib, base64
        code_verifier = secrets.token_urlsafe(64)
        code_challenge = base64.urlsafe_b64encode(
            hashlib.sha256(code_verifier.encode()).digest()
        ).rstrip(b"=").decode()
        _oauth_states[state]["code_verifier"] = code_verifier
        params["code_challenge"] = code_challenge
        params["code_challenge_method"] = "S256"

    url = f"{cfg['auth_url']}?{urlencode(params)}"
    return RedirectResponse(url)


# ── Callback ──────────────────────────────────────────────────────────────────

@router.get("/{platform}/callback")
async def platform_callback(platform: str, code: str, state: str, request: Request):
    if platform not in PLATFORM_CONFIGS:
        raise HTTPException(400, f"Unsupported platform: {platform}")

    # Verify state
    state_data = _oauth_states.pop(state, None)
    if not state_data or state_data["platform"] != platform:
        raise HTTPException(400, "Invalid OAuth state. Please try connecting again.")

    user_id = state_data["user_id"]
    cfg = PLATFORM_CONFIGS[platform]
    client_id, client_secret = _get_client_creds(platform)

    # Exchange code for tokens
    token_data = {
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": _callback_uri(platform),
        "grant_type": "authorization_code",
    }
    if state_data.get("code_verifier"):
        token_data["code_verifier"] = state_data["code_verifier"]

    async with httpx.AsyncClient() as client:
        token_resp = await client.post(cfg["token_url"], data=token_data)
        if token_resp.status_code not in (200, 201):
            raise HTTPException(400, f"Token exchange failed for {platform}: {token_resp.text}")

        tokens = token_resp.json()
        access_token = tokens.get("access_token", "")
        refresh_token = tokens.get("refresh_token", "")
        expires_in = tokens.get("expires_in", 3600)

        # Fetch platform profile
        headers = {"Authorization": f"Bearer {access_token}"}
        profile_url = cfg["profile_url"]

        # TikTok needs different header format
        if platform == "tiktok":
            headers = {"Authorization": f"Bearer {access_token}"}
            profile_resp = await client.get(
                profile_url,
                headers=headers,
                params={"fields": "open_id,display_name,avatar_url"}
            )
        else:
            profile_resp = await client.get(profile_url, headers=headers)

        profile_raw = profile_resp.json() if profile_resp.status_code == 200 else {}

    # Normalize profile across platforms
    display_name, profile_pic, platform_user_id = _extract_profile(platform, profile_raw)

    # Build account document - encrypt tokens at rest
    account_doc = {
        "user_id": user_id,          # our app user (google_id)
        "platform": platform,
        "platform_user_id": platform_user_id,
        "display_name": display_name,
        "profile_pic": profile_pic,
        "access_token": encrypt_token(access_token) if access_token else "",
        "refresh_token": encrypt_token(refresh_token) if refresh_token else "",
        "token_expires_in": expires_in,
        "scopes": cfg["scopes"],
        "connected_at": datetime.utcnow().isoformat(),
        "last_refreshed": datetime.utcnow().isoformat(),
        "status": "active",
    }

    # Upsert: one record per user+platform
    await social_accounts_col().update_one(
        {"user_id": user_id, "platform": platform},
        {"$set": account_doc},
        upsert=True,
    )

    # Redirect back to frontend accounts page with success flag
    return RedirectResponse(f"{settings.FRONTEND_URL}/accounts?connected={platform}")


def _extract_profile(platform: str, raw: dict) -> tuple:
    """Normalize profile data across different platform API responses."""
    if platform == "linkedin":
        return (
            raw.get("name", raw.get("sub", "LinkedIn User")),
            raw.get("picture", ""),
            raw.get("sub", ""),
        )
    elif platform == "x":
        data = raw.get("data", raw)
        return data.get("name", "X User"), "", data.get("id", "")
    elif platform == "instagram":
        return raw.get("name", "Meta User"), raw.get("picture", {}).get("data", {}).get("url", ""), raw.get("id", "")
    elif platform == "tiktok":
        data = raw.get("data", {}).get("user", raw)
        return data.get("display_name", "TikTok User"), data.get("avatar_url", ""), data.get("open_id", "")
    elif platform == "pinterest":
        return raw.get("username", "Pinterest User"), raw.get("profile_image", ""), raw.get("id", "")
    elif platform == "youtube":
        items = raw.get("items", [{}])
        snippet = items[0].get("snippet", {}) if items else {}
        thumb = snippet.get("thumbnails", {}).get("default", {}).get("url", "")
        return snippet.get("title", "YouTube Channel"), thumb, items[0].get("id", "") if items else ""
    return "Unknown", "", ""


# ── List accounts ─────────────────────────────────────────────────────────────

@router.get("/accounts")
async def list_accounts(current_user: dict = Depends(get_current_user)):
    """Return all connected social accounts for the logged-in user (no tokens exposed)."""
    cursor = social_accounts_col().find(
        {"user_id": current_user["google_id"]},
        {
            "_id": 0,
            "access_token": 0,    # never expose encrypted tokens to frontend
            "refresh_token": 0,
        }
    )
    accounts = await cursor.to_list(length=100)
    return {"accounts": accounts}


# ── Disconnect ────────────────────────────────────────────────────────────────

@router.delete("/{platform}/disconnect")
async def disconnect_platform(platform: str, current_user: dict = Depends(get_current_user)):
    result = await social_accounts_col().delete_one(
        {"user_id": current_user["google_id"], "platform": platform}
    )
    if result.deleted_count == 0:
        raise HTTPException(404, f"No connected {platform} account found")
    return {"message": f"{platform} disconnected successfully"}


# ── Refresh token (internal utility) ─────────────────────────────────────────

async def get_decrypted_token(user_id: str, platform: str) -> str:
    """Fetch and decrypt the access token for a given user+platform. Used by posting services."""
    account = await social_accounts_col().find_one({"user_id": user_id, "platform": platform})
    if not account:
        raise HTTPException(404, f"No connected {platform} account")
    return decrypt_token(account["access_token"])
