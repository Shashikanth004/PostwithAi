"""
Google Sign-In router — NO DATABASE storage.

Flow:
  1. Frontend redirects user to /auth/google/login
  2. Google redirects back to /auth/google/callback with ?code=...
  3. We exchange code for Google user info
  4. Issue our own JWT containing the user info directly (no DB write)
  5. Redirect to frontend with token in URL fragment
"""
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import RedirectResponse
import httpx
from ..core.config import settings
from ..core.security import create_access_token, decode_access_token

router = APIRouter(prefix="/auth", tags=["auth"])

GOOGLE_AUTH_URL  = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"


def _callback_uri():
    return f"{settings.BACKEND_URL}/auth/google/callback"


@router.get("/google/login")
async def google_login():
    """Redirect the user to Google's OAuth consent page."""
    params = {
        "client_id":     settings.GOOGLE_CLIENT_ID,
        "redirect_uri":  _callback_uri(),
        "response_type": "code",
        "scope":         "openid email profile",
        "access_type":   "online",   # no refresh token needed — we don't store anything
        "prompt":        "select_account",
    }
    from urllib.parse import urlencode
    return RedirectResponse(f"{GOOGLE_AUTH_URL}?{urlencode(params)}")


@router.get("/google/callback")
async def google_callback(code: str):
    """Exchange the Google auth code for user info, issue a stateless JWT (no DB)."""
    async with httpx.AsyncClient() as client:
        # Exchange code for Google access token
        token_resp = await client.post(GOOGLE_TOKEN_URL, data={
            "code":          code,
            "client_id":     settings.GOOGLE_CLIENT_ID,
            "client_secret": settings.GOOGLE_CLIENT_SECRET,
            "redirect_uri":  _callback_uri(),
            "grant_type":    "authorization_code",
        })
        if token_resp.status_code != 200:
            raise HTTPException(400, f"Google token exchange failed: {token_resp.text}")

        google_access_token = token_resp.json().get("access_token")

        # Fetch Google user info
        info_resp = await client.get(
            GOOGLE_USERINFO_URL,
            headers={"Authorization": f"Bearer {google_access_token}"},
        )
        if info_resp.status_code != 200:
            raise HTTPException(400, "Failed to fetch Google user info")

        google_user = info_resp.json()

    # Embed user info directly into our JWT — zero DB writes
    jwt_token = create_access_token({
        "sub":     google_user["id"],
        "email":   google_user.get("email", ""),
        "name":    google_user.get("name", ""),
        "picture": google_user.get("picture", ""),
    })

    # Redirect to frontend with token in URL fragment (never in query param to avoid server logs)
    return RedirectResponse(f"{settings.FRONTEND_URL}/auth/callback#token={jwt_token}")


@router.get("/me")
async def get_me(request: Request):
    """Return current user info decoded directly from JWT — no DB lookup."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(401, "Not authenticated")

    payload = decode_access_token(auth_header.split(" ", 1)[1])
    if not payload:
        raise HTTPException(401, "Invalid or expired token")

    # Return the user info that was baked into the JWT
    return {
        "google_id": payload.get("sub"),
        "email":     payload.get("email"),
        "name":      payload.get("name"),
        "picture":   payload.get("picture"),
    }
