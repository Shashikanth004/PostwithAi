"""
Posts router — handles "Post Now" and scheduled post management.

POST /posts/publish        → immediately publish to selected platforms
POST /posts/schedule       → save a post to publish at a future datetime
GET  /posts/scheduled      → list all pending scheduled posts for user
DELETE /posts/scheduled/{id} → cancel a scheduled post
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import asyncio

from ..core.deps import get_current_user
from ..core.database import scheduled_posts_col
from ..services.publisher import dispatch
from bson import ObjectId

router = APIRouter(prefix="/posts", tags=["posts"])


class PublishRequest(BaseModel):
    scheduled_payload: dict          # full payload from orchestration result
    platforms: list[str]             # which platforms to actually post to
    media_url: Optional[str] = None  # optional public URL of uploaded media


class ScheduleRequest(BaseModel):
    scheduled_payload: dict
    platforms: list[str]
    schedules: dict                  # { platform: "2025-01-27T17:00" }
    media_url: Optional[str] = None


# ── Post Now ─────────────────────────────────────────────────────────────────

@router.post("/publish")
async def publish_now(req: PublishRequest, current_user: dict = Depends(get_current_user)):
    """
    Immediately publish to all requested platforms.
    Returns per-platform results (success / error / skipped).
    """
    user_id = current_user["google_id"]
    payload = req.scheduled_payload

    tasks = [
        dispatch(user_id, platform, payload.get(platform, {}), req.media_url)
        for platform in req.platforms
        if platform in payload
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    output = {}
    for platform, result in zip(req.platforms, results):
        if isinstance(result, Exception):
            output[platform] = {"status": "error", "error": str(result)}
        else:
            output[platform] = result

    # Count successes
    successes = sum(1 for r in output.values() if r.get("status") == "published")

    # Log to DB
    await scheduled_posts_col().insert_one({
        "user_id": user_id,
        "type": "immediate",
        "platforms": req.platforms,
        "results": output,
        "published_at": datetime.utcnow().isoformat(),
        "media_url": req.media_url,
    })

    return {
        "status": "complete",
        "published": successes,
        "total": len(req.platforms),
        "results": output,
    }


# ── Schedule ─────────────────────────────────────────────────────────────────

@router.post("/schedule")
async def schedule_post(req: ScheduleRequest, current_user: dict = Depends(get_current_user)):
    """
    Save posts to the scheduled_posts collection for future publishing.
    Each platform can have its own datetime.
    """
    user_id = current_user["google_id"]
    saved = []

    for platform in req.platforms:
        scheduled_at_str = req.schedules.get(platform)
        if not scheduled_at_str:
            continue

        try:
            scheduled_at = datetime.fromisoformat(scheduled_at_str)
        except ValueError:
            raise HTTPException(400, f"Invalid datetime for {platform}: {scheduled_at_str}")

        if scheduled_at <= datetime.utcnow():
            raise HTTPException(400, f"Scheduled time for {platform} must be in the future.")

        doc = {
            "user_id":   user_id,
            "platform":  platform,
            "payload":   req.scheduled_payload.get(platform, {}),
            "media_url": req.media_url,
            "scheduled_at": scheduled_at.isoformat(),
            "status":    "pending",
            "created_at": datetime.utcnow().isoformat(),
        }
        result = await scheduled_posts_col().insert_one(doc)
        saved.append({"platform": platform, "scheduled_at": scheduled_at.isoformat(), "id": str(result.inserted_id)})

    return {
        "status": "scheduled",
        "count": len(saved),
        "scheduled": saved,
    }


# ── List scheduled ────────────────────────────────────────────────────────────

@router.get("/scheduled")
async def list_scheduled(current_user: dict = Depends(get_current_user)):
    """Return all pending scheduled posts for the current user."""
    cursor = scheduled_posts_col().find(
        {"user_id": current_user["google_id"], "status": "pending"},
        sort=[("scheduled_at", 1)]
    )
    posts = []
    async for doc in cursor:
        doc["id"] = str(doc.pop("_id"))
        posts.append(doc)
    return {"scheduled": posts}


# ── Cancel ────────────────────────────────────────────────────────────────────

@router.delete("/scheduled/{post_id}")
async def cancel_scheduled(post_id: str, current_user: dict = Depends(get_current_user)):
    """Cancel a pending scheduled post."""
    try:
        oid = ObjectId(post_id)
    except Exception:
        raise HTTPException(400, "Invalid post ID")

    result = await scheduled_posts_col().update_one(
        {"_id": oid, "user_id": current_user["google_id"], "status": "pending"},
        {"$set": {"status": "cancelled", "cancelled_at": datetime.utcnow().isoformat()}}
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Scheduled post not found or already published/cancelled")

    return {"status": "cancelled", "id": post_id}
