"""
Orchestration router — wraps the Gemini content engine.
Saves orchestration results to MongoDB if user is authenticated.
"""
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends
from typing import Optional
import google.generativeai as genai
import json, os, base64, mimetypes
from datetime import datetime

from ..core.config import settings
from ..core.database import orchestration_history_col
from ..core.deps import get_optional_user

genai.configure(api_key=settings.GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-1.5-pro")

router = APIRouter(tags=["orchestration"])

SUPPORTED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
SUPPORTED_VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/webm", "video/x-msvideo"}
MAX_FILE_SIZE_MB = 20

PLATFORM_RULES = {
    "tiktok": "Short-form vertical video. 3-second visual hook mandatory. Trending audio. Caption under 150 chars. Gen-Z language. If media provided, describe exact edits/cuts.",
    "instagram_reels": "Aesthetic vertical video. Hook in first 2 seconds. Trending audio. Longer caption with emojis. If media provided, suggest filters and crop.",
    "youtube_shorts": "Vertical video. Immediate hook. Educational or entertaining. CTA to subscribe. If media provided, suggest b-roll.",
    "linkedin": "Professional story-driven or listicle. Single sentence paragraphs. Business value. 3-5 niche hashtags.",
    "x": "Pattern-interrupting hook. Thread (1/n) for deep concepts. Under 280 chars each. Punchy.",
    "threads": "Conversational, casual, personal. Relatable observations.",
    "instagram": "Strong hook first line. Storytelling. Emojis. CTA. 5-10 hashtags.",
    "pinterest": "SEO-first. High-converting title. Keyword-rich description. 9:16 ratio.",
    "facebook": "Drive comments and shares. Conversational, relatable. Ask a question.",
    "youtube": "SEO title with keywords. Description with timestamps. Tags.",
}


def build_prompt(base_content, target_platforms, brand_voice, niche, live_trends, scheduled_time, media_context=None):
    platform_instructions = "\n".join(
        f"- {p.upper()}: {PLATFORM_RULES.get(p.lower(), f'Optimize for {p}.')}"
        for p in target_platforms
    )
    media_section = ""
    if media_context:
        media_section = f"\nMEDIA CONTEXT:\n{media_context}\nWeave specific visual details into EVERY platform adaptation.\n"

    return f"""You are the Omnichannel Orchestration Engine. Transform content into platform-native adaptations for maximum algorithmic reach.

BASE CONTENT: {base_content}
TARGET PLATFORMS: {target_platforms}
LIVE TRENDS: {live_trends}
SCHEDULED TIME: {scheduled_time}
BRAND VOICE: {brand_voice}
NICHE: {niche}
{media_section}
PLATFORM RULES:
{platform_instructions}

Return ONLY valid JSON — no markdown, no comments:
{{
  "scheduled_payload": {{
    "<platform>": {{
      "format": "<text|video|image|thread|carousel|reel>",
      "caption": "<optimized caption>",
      "hashtags": ["<tag>"],
      "hook": "<single most powerful hook>",
      "cta": "<call to action>",
      "estimated_reach": "<low|medium|high|viral>",
      "best_post_time": "<suggested time>",
      "media_usage_tip": "<how to use uploaded media>",
      "video_rendering_blueprint": {{
        "visual_instructions": "<edit instructions>",
        "on_screen_text": ["<overlay 1>", "<overlay 2>"],
        "audio_track_directive": "<audio suggestion>",
        "duration_seconds": 30,
        "transitions": "<style>",
        "thumbnail_suggestion": "<description>"
      }},
      "thread_tweets": ["<tweet 1/n>", "<tweet 2/n>"]
    }}
  }}
}}

Rules:
- Generate for ALL: {target_platforms}
- video_rendering_blueprint ONLY for: tiktok, instagram_reels, youtube_shorts, youtube
- thread_tweets ONLY for: x, threads
- Every platform must be DISTINCTLY different"""


def describe_media(file_bytes, mime_type, filename):
    try:
        if mime_type in SUPPORTED_IMAGE_TYPES:
            b64 = base64.b64encode(file_bytes).decode()
            vm = genai.GenerativeModel("gemini-1.5-pro")
            r = vm.generate_content([
                {"inline_data": {"mime_type": mime_type, "data": b64}},
                "Analyze this image for social media: subjects, setting, mood, colors, visual highlights, content category, audience appeal, platform strengths, editing suggestions."
            ])
            return r.text
        elif mime_type in SUPPORTED_VIDEO_TYPES:
            import tempfile
            ext = os.path.splitext(filename)[1] or ".mp4"
            with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                tmp.write(file_bytes)
                tmp_path = tmp.name
            try:
                uploaded = genai.upload_file(path=tmp_path, mime_type=mime_type)
                vm = genai.GenerativeModel("gemini-1.5-pro")
                r = vm.generate_content([uploaded, "Analyze this video for social media: what happens, key moments with timestamps, hook moment, mood, audio, subjects, platform fit, editing blueprint."])
            finally:
                os.unlink(tmp_path)
            return r.text
    except Exception as e:
        return f"Media '{filename}' uploaded. Vision analysis note: {e}"


@router.post("/orchestrate")
async def orchestrate(
    base_content: str = Form(...),
    target_platforms: str = Form(...),
    brand_voice: str = Form(default="professional yet engaging"),
    niche: str = Form(default="general"),
    live_trends: str = Form(default="General trending: authentic storytelling, educational content"),
    scheduled_time: str = Form(default="Immediate"),
    schedules: str = Form(default="{}"),
    media_file: Optional[UploadFile] = File(default=None),
    current_user: Optional[dict] = Depends(get_optional_user),
):
    try:
        platforms_list = json.loads(target_platforms)
        schedules_dict = json.loads(schedules)
    except Exception:
        raise HTTPException(400, "Invalid JSON in target_platforms or schedules")

    if not base_content.strip():
        raise HTTPException(400, "base_content cannot be empty")
    if not platforms_list:
        raise HTTPException(400, "At least one target platform required")

    media_context = None
    media_analyzed = False

    if media_file and media_file.filename:
        file_bytes = await media_file.read()
        if len(file_bytes) / (1024 * 1024) > MAX_FILE_SIZE_MB:
            raise HTTPException(400, f"File too large. Max {MAX_FILE_SIZE_MB}MB.")
        mime_type = media_file.content_type or mimetypes.guess_type(media_file.filename)[0] or ""
        if mime_type not in SUPPORTED_IMAGE_TYPES and mime_type not in SUPPORTED_VIDEO_TYPES:
            raise HTTPException(400, f"Unsupported file type: {mime_type}")
        media_context = describe_media(file_bytes, mime_type, media_file.filename)
        media_analyzed = True

    prompt = build_prompt(base_content, platforms_list, brand_voice, niche, live_trends, scheduled_time, media_context)

    try:
        response = model.generate_content(prompt)
        raw = response.text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip()
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        raise HTTPException(500, f"Failed to parse Gemini response: {e}")
    except Exception as e:
        raise HTTPException(500, f"Gemini API error: {e}")

    scheduled_payload = payload.get("scheduled_payload", payload)
    generated_at = datetime.utcnow().isoformat() + "Z"

    # Save to MongoDB history if user is authenticated
    if current_user:
        history_doc = {
            "user_id": current_user["google_id"],
            "base_content": base_content[:500],  # truncate for storage
            "platforms": platforms_list,
            "brand_voice": brand_voice,
            "niche": niche,
            "scheduled_time": scheduled_time,
            "schedules": schedules_dict,
            "media_analyzed": media_analyzed,
            "media_filename": media_file.filename if media_analyzed else None,
            "result": scheduled_payload,
            "generated_at": generated_at,
        }
        await orchestration_history_col().insert_one(history_doc)

    return {
        "scheduled_payload": scheduled_payload,
        "generated_at": generated_at,
        "platforms_count": len(platforms_list),
        "media_analyzed": media_analyzed,
        "media_context": media_context,
        "schedules": schedules_dict,
    }


@router.get("/history")
async def get_history(current_user: dict = Depends(get_optional_user)):
    """Return past orchestration runs for the logged-in user."""
    if not current_user:
        return {"history": []}
    cursor = orchestration_history_col().find(
        {"user_id": current_user["google_id"]},
        {"_id": 0, "result": 0},  # exclude large result field from list
        sort=[("generated_at", -1)],
        limit=20,
    )
    history = await cursor.to_list(length=20)
    return {"history": history}
