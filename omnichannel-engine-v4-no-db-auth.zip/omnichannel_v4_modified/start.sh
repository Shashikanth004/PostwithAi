#!/bin/bash
set -e
echo "🔥 Starting Omnichannel Orchestration Engine v4..."

# ── Backend ──
cd "$(dirname "$0")/backend"
if [ ! -d "venv" ]; then
  echo "📦 Creating Python virtualenv..."
  python3 -m venv venv
fi
source venv/bin/activate
echo "📦 Installing backend dependencies..."
pip install -r requirements.txt -q

if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "⚠️  Created backend/.env — fill in your API keys before using!"
fi

uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
echo "✅ Backend: http://localhost:8000 (PID $BACKEND_PID)"
echo "   API docs: http://localhost:8000/docs"

# ── Frontend ──
cd ../frontend
if [ ! -d "node_modules" ]; then
  echo "📦 Installing frontend dependencies..."
  npm install
fi
npm run dev &
FRONTEND_PID=$!
echo "✅ Frontend: http://localhost:5173 (PID $FRONTEND_PID)"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🚀 Open: http://localhost:5173"
echo "  📄 API:  http://localhost:8000/docs"
echo "  🍃 Make sure MongoDB is running on port 27017"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Press Ctrl+C to stop both servers"
echo ""

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Stopped.'" INT
wait
