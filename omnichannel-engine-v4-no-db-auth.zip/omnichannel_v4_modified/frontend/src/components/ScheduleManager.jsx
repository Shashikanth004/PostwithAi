import React, { useState } from 'react'
import { PLATFORMS } from '../utils/constants'

// Get local datetime string for min attribute (now)
function getNowLocal() {
  const now = new Date()
  now.setSeconds(0, 0)
  return now.toISOString().slice(0, 16)
}

// Format a datetime-local value to a human-readable string
function formatDisplay(dtStr) {
  if (!dtStr) return null
  const d = new Date(dtStr)
  return d.toLocaleString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric',
    year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true,
  })
}

// Suggested quick-pick times relative to now
function getQuickPicks() {
  const picks = []
  const labels = [
    { label: 'In 1 hour',    mins: 60 },
    { label: 'Tonight 8 PM', fn: () => { const d = new Date(); d.setHours(20, 0, 0, 0); if (d < new Date()) d.setDate(d.getDate() + 1); return d } },
    { label: 'Tomorrow 9 AM',fn: () => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d } },
    { label: 'This weekend',  fn: () => { const d = new Date(); const day = d.getDay(); const diff = day === 6 ? 1 : (6 - day); d.setDate(d.getDate() + diff); d.setHours(10, 0, 0, 0); return d } },
    { label: 'Next Monday',   fn: () => { const d = new Date(); const diff = (8 - d.getDay()) % 7 || 7; d.setDate(d.getDate() + diff); d.setHours(9, 0, 0, 0); return d } },
  ]
  labels.forEach(({ label, mins, fn }) => {
    const d = fn ? fn() : (() => { const x = new Date(); x.setMinutes(x.getMinutes() + mins, 0, 0); return x })()
    picks.push({ label, value: d.toISOString().slice(0, 16) })
  })
  return picks
}

// Per-platform optimal posting time suggestions
const OPTIMAL_TIMES = {
  tiktok:           { label: 'Tue–Fri 7–9 PM', hint: 'Peak Gen-Z scroll time' },
  instagram_reels:  { label: 'Mon–Fri 11 AM–1 PM', hint: 'Lunch break engagement spike' },
  youtube_shorts:   { label: 'Sat–Sun 9–11 AM', hint: 'Weekend morning discovery' },
  linkedin:         { label: 'Tue–Thu 8–10 AM', hint: 'Pre-meeting professional window' },
  x:                { label: 'Weekdays 9 AM & 5 PM', hint: 'Commute & lunch spikes' },
  threads:          { label: 'Daily 6–8 PM', hint: 'Evening casual scroll' },
  instagram:        { label: 'Mon, Wed, Fri 11 AM', hint: 'Algorithm sweet spot' },
  pinterest:        { label: 'Sat 8–11 PM', hint: 'Weekend discovery peak' },
  facebook:         { label: 'Wed–Fri 1–3 PM', hint: 'Afternoon engagement window' },
  youtube:          { label: 'Thu–Fri 3–5 PM', hint: 'After-school / after-work' },
}

export default function ScheduleManager({ schedules, onChange, platforms }) {
  const [mode, setMode] = useState('same') // 'same' | 'per_platform'
  const [sameDateTime, setSameDateTime] = useState('')
  const quickPicks = getQuickPicks()

  const handleSameChange = (val) => {
    setSameDateTime(val)
    const next = {}
    platforms.forEach(p => { next[p] = val })
    onChange(next)
  }

  const handlePerPlatform = (platformId, val) => {
    onChange({ ...schedules, [platformId]: val })
  }

  const applyQuickPick = (val) => {
    if (mode === 'same') {
      handleSameChange(val)
    }
  }

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <label style={{
          fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)',
          letterSpacing: '0.12em', textTransform: 'uppercase',
        }}>
          📅 Schedule
        </label>
        {/* Mode toggle */}
        <div style={{ display: 'flex', gap: 1, border: '1px solid var(--border)', borderRadius: 4, overflow: 'hidden' }}>
          {[{ id: 'same', label: 'All Same' }, { id: 'per_platform', label: 'Per Platform' }].map(m => (
            <button key={m.id} onClick={() => setMode(m.id)} style={{
              background: mode === m.id ? 'var(--border2)' : 'transparent',
              border: 'none', color: mode === m.id ? 'var(--text)' : 'var(--text3)',
              fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.08em',
              padding: '5px 10px', cursor: 'pointer', textTransform: 'uppercase',
              transition: 'all 0.15s',
            }}>
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {mode === 'same' ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {/* Single datetime picker */}
          <div style={{ position: 'relative' }}>
            <input
              type="datetime-local"
              value={sameDateTime}
              min={getNowLocal()}
              onChange={e => handleSameChange(e.target.value)}
              style={{
                background: 'var(--bg3)', border: `1px solid ${sameDateTime ? 'var(--accent)' : 'var(--border)'}`,
                borderRadius: 6, color: 'var(--text)', fontFamily: 'var(--font-mono)',
                fontSize: 13, padding: '10px 14px', width: '100%', outline: 'none',
                colorScheme: 'dark', transition: 'border-color 0.15s',
              }}
            />
            {sameDateTime && (
              <div style={{
                marginTop: 6, fontFamily: 'var(--font-mono)', fontSize: 10,
                color: 'var(--accent)', letterSpacing: '0.06em',
              }}>
                ◆ {formatDisplay(sameDateTime)}
              </div>
            )}
          </div>

          {/* Quick picks */}
          <div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em', marginBottom: 6, textTransform: 'uppercase' }}>
              Quick Pick
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {quickPicks.map(qp => (
                <button
                  key={qp.label}
                  onClick={() => applyQuickPick(qp.value)}
                  style={{
                    background: sameDateTime === qp.value ? 'rgba(200,255,0,0.1)' : 'var(--bg3)',
                    border: `1px solid ${sameDateTime === qp.value ? 'var(--accent)' : 'var(--border)'}`,
                    borderRadius: 4, color: sameDateTime === qp.value ? 'var(--accent)' : 'var(--text2)',
                    fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.06em',
                    padding: '5px 10px', cursor: 'pointer', transition: 'all 0.15s',
                    textTransform: 'uppercase',
                  }}
                >
                  {qp.label}
                </button>
              ))}
              {sameDateTime && (
                <button onClick={() => handleSameChange('')} style={{
                  background: 'transparent', border: '1px solid var(--border)', borderRadius: 4,
                  color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 9,
                  padding: '5px 10px', cursor: 'pointer', letterSpacing: '0.06em',
                }}>
                  CLEAR
                </button>
              )}
            </div>
          </div>

          {/* Optimal time hints */}
          {platforms.length > 0 && (
            <div style={{
              background: 'var(--bg3)', border: '1px solid var(--border)',
              borderRadius: 6, padding: 12, display: 'flex', flexDirection: 'column', gap: 6,
            }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em', marginBottom: 2, textTransform: 'uppercase' }}>
                Optimal Times by Platform
              </div>
              {platforms.map(p => {
                const meta = PLATFORMS.find(pl => pl.id === p)
                const opt = OPTIMAL_TIMES[p]
                if (!opt) return null
                return (
                  <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 12 }}>{meta?.icon}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: meta?.color, minWidth: 100 }}>
                      {meta?.label}
                    </span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text2)' }}>
                      {opt.label}
                    </span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)' }}>
                      · {opt.hint}
                    </span>
                  </div>
                )
              })}
            </div>
          )}
        </div>

      ) : (
        /* Per-platform schedule */
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {platforms.length === 0 ? (
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', padding: '12px 0' }}>
              Select platforms first to set per-platform schedules.
            </div>
          ) : (
            platforms.map(p => {
              const meta = PLATFORMS.find(pl => pl.id === p)
              const opt = OPTIMAL_TIMES[p]
              const val = schedules[p] || ''
              return (
                <div key={p} style={{
                  background: 'var(--bg3)', border: `1px solid ${val ? meta?.color || 'var(--border2)' : 'var(--border)'}`,
                  borderRadius: 6, padding: 12, transition: 'border-color 0.2s',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <span style={{ fontSize: 14 }}>{meta?.icon}</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: meta?.color }}>
                      {meta?.label}
                    </span>
                    {opt && (
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', marginLeft: 'auto' }}>
                        Best: {opt.label}
                      </span>
                    )}
                  </div>
                  <input
                    type="datetime-local"
                    value={val}
                    min={getNowLocal()}
                    onChange={e => handlePerPlatform(p, e.target.value)}
                    style={{
                      background: 'var(--bg)', border: '1px solid var(--border2)',
                      borderRadius: 4, color: 'var(--text)', fontFamily: 'var(--font-mono)',
                      fontSize: 12, padding: '8px 12px', width: '100%', outline: 'none',
                      colorScheme: 'dark',
                    }}
                  />
                  {val && (
                    <div style={{ marginTop: 5, fontFamily: 'var(--font-mono)', fontSize: 9, color: meta?.color, letterSpacing: '0.06em' }}>
                      ◆ {formatDisplay(val)}
                    </div>
                  )}
                </div>
              )
            })
          )}
        </div>
      )}
    </div>
  )
}
