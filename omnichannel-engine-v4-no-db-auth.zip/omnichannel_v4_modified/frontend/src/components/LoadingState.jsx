import React, { useState, useEffect } from 'react'

const STAGES_NO_MEDIA = [
  { label: 'Parsing base content...', pct: 15 },
  { label: 'Fetching live trends...', pct: 30 },
  { label: 'Analyzing platform algorithms...', pct: 50 },
  { label: 'Generating platform-native adaptations...', pct: 70 },
  { label: 'Optimizing for maximum reach...', pct: 88 },
  { label: 'Finalizing scheduled payload...', pct: 96 },
]

const STAGES_WITH_MEDIA = [
  { label: 'Uploading media file...', pct: 10 },
  { label: 'Gemini Vision analyzing your media...', pct: 28 },
  { label: 'Extracting visual context & key moments...', pct: 44 },
  { label: 'Fetching live trends...', pct: 56 },
  { label: 'Architecting platform-native adaptations...', pct: 72 },
  { label: 'Weaving visual context into every platform...', pct: 86 },
  { label: 'Finalizing scheduled payload...', pct: 96 },
]

export default function LoadingState({ platforms = [], hasMedia = false }) {
  const STAGES = hasMedia ? STAGES_WITH_MEDIA : STAGES_NO_MEDIA
  const [stageIdx, setStageIdx] = useState(0)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setStageIdx(i => Math.min(i + 1, STAGES.length - 1))
    }, hasMedia ? 2400 : 1800)
    return () => clearInterval(interval)
  }, [hasMedia])

  useEffect(() => {
    const target = STAGES[stageIdx].pct
    const step = setInterval(() => {
      setProgress(p => {
        if (p >= target) { clearInterval(step); return p }
        return p + 1
      })
    }, 18)
    return () => clearInterval(step)
  }, [stageIdx])

  const isVisionStage = hasMedia && stageIdx >= 1 && stageIdx <= 2

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '80px 32px', gap: 40,
    }}>
      {/* Spinner */}
      <div style={{ position: 'relative', width: 88, height: 88 }}>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '1px solid var(--border)' }} />
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '50%',
          border: '2px solid transparent',
          borderTopColor: isVisionStage ? '#7c3aed' : 'var(--accent)',
          animation: 'spin 1s linear infinite',
          transition: 'border-top-color 0.4s',
        }} />
        <div style={{
          position: 'absolute', inset: 10, borderRadius: '50%',
          border: '1px solid transparent',
          borderTopColor: isVisionStage ? '#a78bfa' : 'rgba(200,255,0,0.4)',
          animation: 'spin 1.6s linear infinite reverse',
          transition: 'border-top-color 0.4s',
        }} />
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700,
          color: isVisionStage ? '#a78bfa' : 'var(--accent)',
          transition: 'color 0.4s',
        }}>
          {progress}%
        </div>
      </div>

      {/* Stage */}
      <div style={{ textAlign: 'center', maxWidth: 400 }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 10,
          color: isVisionStage ? '#a78bfa' : 'var(--accent)',
          letterSpacing: '0.15em', marginBottom: 8, transition: 'color 0.4s',
        }}>
          {isVisionStage ? '◆ GEMINI VISION ACTIVE' : '◆ ENGINE RUNNING'}
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, color: 'var(--text)', fontWeight: 600, lineHeight: 1.4 }}>
          {STAGES[stageIdx].label}
        </div>
        {hasMedia && stageIdx === 1 && (
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', marginTop: 8, lineHeight: 1.5 }}>
            Analyzing subjects, mood, visual highlights,<br />and platform fit of your media...
          </div>
        )}
      </div>

      {/* Progress bar */}
      <div style={{ width: '100%', maxWidth: 440 }}>
        <div style={{ height: 2, background: 'var(--border)', borderRadius: 1, overflow: 'hidden' }}>
          <div style={{
            height: '100%', width: `${progress}%`,
            background: isVisionStage
              ? 'linear-gradient(90deg, #7c3aed, #a78bfa)'
              : 'linear-gradient(90deg, var(--accent3), var(--accent))',
            transition: 'width 0.1s, background 0.4s',
            boxShadow: isVisionStage ? '0 0 10px #7c3aed' : '0 0 12px var(--accent)',
          }} />
        </div>

        {/* Step dots */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
          {STAGES.map((s, i) => (
            <div key={i} style={{
              width: 5, height: 5, borderRadius: '50%',
              background: i <= stageIdx ? (isVisionStage ? '#7c3aed' : 'var(--accent)') : 'var(--border2)',
              transition: 'background 0.3s',
            }} />
          ))}
        </div>
      </div>

      {/* Platform tags */}
      {platforms.length > 0 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', maxWidth: 440 }}>
          {platforms.map((p, i) => (
            <div key={p} style={{
              fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em',
              color: i <= stageIdx * 1.4 ? 'var(--accent)' : 'var(--text3)',
              textTransform: 'uppercase', transition: 'color 0.4s',
              border: `1px solid ${i <= stageIdx * 1.4 ? 'rgba(200,255,0,0.2)' : 'transparent'}`,
              borderRadius: 2, padding: '2px 6px',
            }}>
              {p.replace(/_/g, ' ')}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
