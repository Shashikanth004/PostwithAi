import React, { useState, useEffect } from 'react'
import { api, getSocialAccounts } from '../utils/api'
import { PLATFORMS } from '../utils/constants'

const STATUS_STYLES = {
  published:       { color: '#22c55e', bg: 'rgba(34,197,94,0.08)',   border: 'rgba(34,197,94,0.25)',   icon: '✓' },
  scheduled:       { color: 'var(--accent)', bg: 'rgba(200,255,0,0.06)', border: 'rgba(200,255,0,0.2)', icon: '📅' },
  error:           { color: 'var(--accent2)', bg: 'rgba(255,107,53,0.08)', border: 'rgba(255,107,53,0.25)', icon: '✗' },
  skipped:         { color: '#888', bg: 'var(--bg3)', border: 'var(--border)', icon: '–' },
  manual_required: { color: '#f59e0b', bg: 'rgba(245,158,11,0.08)', border: 'rgba(245,158,11,0.25)', icon: '📋' },
}

function ResultBadge({ result }) {
  const style = STATUS_STYLES[result.status] || STATUS_STYLES.skipped
  return (
    <div style={{
      background: style.bg, border: `1px solid ${style.border}`,
      borderRadius: 6, padding: '8px 12px', fontSize: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: result.error || result.url ? 4 : 0 }}>
        <span style={{ color: style.color, fontWeight: 700 }}>{style.icon}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: style.color, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {result.status.replace('_', ' ')}
        </span>
      </div>
      {result.error && <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, color: 'var(--accent2)', lineHeight: 1.4 }}>{result.error}</div>}
      {result.url && (
        <a href={result.url} target="_blank" rel="noreferrer" style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: style.color, textDecoration: 'none', letterSpacing: '0.06em' }}>
          VIEW POST ↗
        </a>
      )}
      {result.reason && <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, color: 'var(--text2)', lineHeight: 1.4, marginTop: 2 }}>{result.reason}</div>}
      {result.note && <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, color: 'var(--text3)', lineHeight: 1.4, marginTop: 2 }}>{result.note}</div>}
    </div>
  )
}

export default function PostNowPanel({ scheduledPayload, schedules = {}, mediaUrl }) {
  const [connectedAccounts, setConnectedAccounts] = useState([])
  const [selectedPlatforms, setSelectedPlatforms] = useState([])
  const [posting, setPosting]   = useState(false)
  const [scheduling, setScheduling] = useState(false)
  const [results, setResults]   = useState(null)
  const [scheduleResults, setScheduleResults] = useState(null)
  const [error, setError]       = useState(null)
  const [mode, setMode]         = useState('now') // 'now' | 'schedule'

  const availablePlatforms = Object.keys(scheduledPayload)

  useEffect(() => {
    getSocialAccounts()
      .then(d => {
        const ids = (d.accounts || []).map(a => a.platform)
        setConnectedAccounts(ids)
        // Pre-select platforms that are both generated AND connected
        setSelectedPlatforms(availablePlatforms.filter(p => ids.includes(p) || ids.includes(p.replace('_reels','').replace('_shorts',''))))
      })
      .catch(() => {})
  }, [])

  const togglePlatform = (p) => {
    setSelectedPlatforms(prev =>
      prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
    )
  }

  const isConnected = (platformId) => {
    // Also check parent platform (instagram_reels → instagram, youtube_shorts → youtube)
    const parent = platformId.replace('_reels', '').replace('_shorts', '').replace('youtube_shorts', 'youtube')
    return connectedAccounts.includes(platformId) || connectedAccounts.includes(parent)
  }

  const handlePostNow = async () => {
    if (!selectedPlatforms.length) { setError('Select at least one platform to post to.'); return }
    setError(null); setPosting(true); setResults(null)
    try {
      const res = await api.post('/posts/publish', {
        scheduled_payload: scheduledPayload,
        platforms: selectedPlatforms,
        media_url: mediaUrl || null,
      })
      setResults(res.data)
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || 'Post failed.')
    } finally { setPosting(false) }
  }

  const handleSchedule = async () => {
    const platformsWithSchedule = selectedPlatforms.filter(p => schedules[p])
    if (!platformsWithSchedule.length) {
      setError('Set a schedule date for at least one selected platform first.')
      return
    }
    setError(null); setScheduling(true); setScheduleResults(null)
    try {
      const res = await api.post('/posts/schedule', {
        scheduled_payload: scheduledPayload,
        platforms: platformsWithSchedule,
        schedules,
        media_url: mediaUrl || null,
      })
      setScheduleResults(res.data)
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || 'Scheduling failed.')
    } finally { setScheduling(false) }
  }

  return (
    <div style={{
      marginTop: 32, background: 'var(--bg2)',
      border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: '14px 20px', borderBottom: '1px solid var(--border)',
        background: 'var(--bg3)', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>
            🚀 Publish
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', marginTop: 2, letterSpacing: '0.1em' }}>
            POST DIRECTLY TO YOUR CONNECTED ACCOUNTS
          </div>
        </div>
        {/* Mode toggle */}
        <div style={{ display: 'flex', gap: 1, border: '1px solid var(--border)', borderRadius: 4, overflow: 'hidden' }}>
          {[{ id: 'now', label: '⚡ Post Now' }, { id: 'schedule', label: '📅 Schedule' }].map(m => (
            <button key={m.id} onClick={() => setMode(m.id)} style={{
              background: mode === m.id ? 'var(--accent)' : 'transparent',
              border: 'none', color: mode === m.id ? '#000' : 'var(--text3)',
              fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.08em',
              padding: '6px 12px', cursor: 'pointer', fontWeight: mode === m.id ? 700 : 400,
            }}>
              {m.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: 20 }}>
        {/* Platform selector */}
        {!results && !scheduleResults && (
          <>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 10 }}>
              Select platforms to {mode === 'now' ? 'post to' : 'schedule'}
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
              {availablePlatforms.map(p => {
                const meta = PLATFORMS.find(pl => pl.id === p)
                const connected = isConnected(p)
                const selected = selectedPlatforms.includes(p)
                const hasSchedule = !!schedules[p]
                return (
                  <button
                    key={p}
                    onClick={() => connected && togglePlatform(p)}
                    title={!connected ? `Connect ${meta?.label} in Accounts first` : ''}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 6,
                      padding: '6px 12px',
                      background: selected ? `${meta?.color}18` : 'var(--bg3)',
                      border: `1px solid ${selected ? meta?.color : connected ? 'var(--border2)' : 'var(--border)'}`,
                      borderRadius: 6, cursor: connected ? 'pointer' : 'not-allowed',
                      opacity: connected ? 1 : 0.4, transition: 'all 0.15s',
                    }}
                  >
                    <span style={{ fontSize: 14 }}>{meta?.icon}</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, color: selected ? meta?.color : 'var(--text2)' }}>
                      {meta?.label}
                    </span>
                    {connected && (
                      <span style={{ width: 5, height: 5, borderRadius: '50%', background: selected ? meta?.color : '#444', flexShrink: 0 }} />
                    )}
                    {!connected && (
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 8, color: 'var(--text3)' }}>NOT CONNECTED</span>
                    )}
                    {mode === 'schedule' && hasSchedule && connected && (
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 8, color: 'var(--accent)' }}>
                        {new Date(schedules[p]).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                      </span>
                    )}
                  </button>
                )
              })}
            </div>

            {connectedAccounts.length === 0 && (
              <div style={{
                background: 'rgba(255,107,53,0.06)', border: '1px solid rgba(255,107,53,0.2)',
                borderRadius: 6, padding: '10px 14px', marginBottom: 16,
                fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--accent2)', lineHeight: 1.5,
              }}>
                ⚠ No accounts connected yet. Go to{' '}
                <a href="/accounts" style={{ color: 'var(--accent)', textDecoration: 'none', fontWeight: 600 }}>Accounts</a>
                {' '}to connect LinkedIn, X, Instagram, TikTok, Pinterest, or YouTube.
              </div>
            )}

            {error && (
              <div style={{ background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.3)', borderRadius: 6, padding: '10px 14px', marginBottom: 12, fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent2)' }}>
                ⚠ {error}
              </div>
            )}

            {mode === 'now' ? (
              <button
                onClick={handlePostNow}
                disabled={posting || !selectedPlatforms.length}
                style={{
                  background: selectedPlatforms.length && !posting ? 'var(--accent)' : 'var(--bg3)',
                  border: 'none', borderRadius: 6, color: '#000',
                  fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14,
                  padding: '12px 28px', cursor: selectedPlatforms.length && !posting ? 'pointer' : 'not-allowed',
                  opacity: selectedPlatforms.length && !posting ? 1 : 0.4, transition: 'all 0.2s',
                }}
              >
                {posting
                  ? '⏳ Publishing...'
                  : `⚡ POST NOW TO ${selectedPlatforms.length} PLATFORM${selectedPlatforms.length !== 1 ? 'S' : ''}`}
              </button>
            ) : (
              <button
                onClick={handleSchedule}
                disabled={scheduling || !selectedPlatforms.length}
                style={{
                  background: selectedPlatforms.length && !scheduling ? 'var(--accent)' : 'var(--bg3)',
                  border: 'none', borderRadius: 6, color: '#000',
                  fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14,
                  padding: '12px 28px', cursor: selectedPlatforms.length && !scheduling ? 'pointer' : 'not-allowed',
                  opacity: selectedPlatforms.length && !scheduling ? 1 : 0.4, transition: 'all 0.2s',
                }}
              >
                {scheduling ? '⏳ Scheduling...' : `📅 SCHEDULE ${selectedPlatforms.length} PLATFORM${selectedPlatforms.length !== 1 ? 'S' : ''}`}
              </button>
            )}
          </>
        )}

        {/* Publish results */}
        {results && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#22c55e', boxShadow: '0 0 8px #22c55e' }} />
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>
                Published — {results.published}/{results.total} platforms
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {Object.entries(results.results || {}).map(([p, r]) => {
                const meta = PLATFORMS.find(pl => pl.id === p)
                return (
                  <div key={p} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <span style={{ fontSize: 16, flexShrink: 0, marginTop: 2 }}>{meta?.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, color: meta?.color, marginBottom: 4 }}>
                        {meta?.label}
                      </div>
                      <ResultBadge result={r} />
                    </div>
                  </div>
                )
              })}
            </div>
            <button onClick={() => setResults(null)} style={{ marginTop: 16, background: 'transparent', border: '1px solid var(--border)', borderRadius: 4, color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 9, padding: '5px 12px', cursor: 'pointer', letterSpacing: '0.1em' }}>
              ← POST TO MORE PLATFORMS
            </button>
          </div>
        )}

        {/* Schedule results */}
        {scheduleResults && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 8px var(--accent)' }} />
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>
                {scheduleResults.count} post{scheduleResults.count !== 1 ? 's' : ''} scheduled ✓
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {(scheduleResults.scheduled || []).map(s => {
                const meta = PLATFORMS.find(pl => pl.id === s.platform)
                return (
                  <div key={s.platform} style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 6, padding: '8px 12px' }}>
                    <span>{meta?.icon}</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, color: meta?.color, flex: 1 }}>{meta?.label}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent)' }}>
                      {new Date(s.scheduled_at).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                    </span>
                  </div>
                )
              })}
            </div>
            <button onClick={() => setScheduleResults(null)} style={{ marginTop: 16, background: 'transparent', border: '1px solid var(--border)', borderRadius: 4, color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 9, padding: '5px 12px', cursor: 'pointer', letterSpacing: '0.1em' }}>
              ← SCHEDULE MORE
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
