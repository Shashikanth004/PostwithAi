import React, { useState, useRef, useCallback } from 'react'

const ACCEPTED = {
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
  'image/webp': ['.webp'],
  'image/gif': ['.gif'],
  'video/mp4': ['.mp4'],
  'video/quicktime': ['.mov'],
  'video/webm': ['.webm'],
  'video/x-msvideo': ['.avi'],
}
const ACCEPT_STRING = Object.values(ACCEPTED).flat().join(',')
const MAX_MB = 20

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function isVideo(file) {
  return file?.type?.startsWith('video/')
}

export default function MediaUploader({ file, onChange }) {
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState(null)
  const [preview, setPreview] = useState(null)
  const inputRef = useRef(null)

  const handleFile = useCallback((f) => {
    setError(null)
    if (!f) return

    const sizeMB = f.size / (1024 * 1024)
    if (sizeMB > MAX_MB) {
      setError(`File too large (${formatBytes(f.size)}). Max is ${MAX_MB}MB.`)
      return
    }
    if (!Object.keys(ACCEPTED).includes(f.type)) {
      setError(`Unsupported type: ${f.type}. Use JPG, PNG, WEBP, GIF, MP4, MOV, or WEBM.`)
      return
    }

    onChange(f)

    // Generate preview
    const url = URL.createObjectURL(f)
    setPreview(url)
  }, [onChange])

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setDragging(false)
    const f = e.dataTransfer.files?.[0]
    if (f) handleFile(f)
  }, [handleFile])

  const onDragOver = (e) => { e.preventDefault(); setDragging(true) }
  const onDragLeave = () => setDragging(false)

  const clearFile = (e) => {
    e.stopPropagation()
    onChange(null)
    setPreview(null)
    setError(null)
    if (inputRef.current) inputRef.current.value = ''
  }

  return (
    <div>
      <label style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8,
      }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
          Media Upload
        </span>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent3)',
          background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.25)',
          borderRadius: 2, padding: '2px 7px', letterSpacing: '0.08em',
        }}>
          GEMINI VISION
        </span>
      </label>

      {/* Drop zone */}
      <div
        onClick={() => !file && inputRef.current?.click()}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        style={{
          border: `1px dashed ${dragging ? 'var(--accent)' : file ? 'var(--accent3)' : 'var(--border2)'}`,
          borderRadius: 8,
          background: dragging
            ? 'rgba(200,255,0,0.04)'
            : file
            ? 'rgba(124,58,237,0.04)'
            : 'var(--bg3)',
          transition: 'all 0.2s',
          cursor: file ? 'default' : 'pointer',
          overflow: 'hidden',
          minHeight: file ? 'auto' : 120,
          position: 'relative',
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT_STRING}
          style={{ display: 'none' }}
          onChange={e => handleFile(e.target.files?.[0])}
        />

        {!file ? (
          /* Empty state */
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', padding: '28px 16px', gap: 10,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: '50%',
              background: 'rgba(200,255,0,0.06)', border: '1px solid rgba(200,255,0,0.15)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20,
            }}>
              {dragging ? '⬇' : '📎'}
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, color: 'var(--text)' }}>
                {dragging ? 'Drop it here' : 'Drop photo, video or reel'}
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', marginTop: 4 }}>
                or click to browse · max {MAX_MB}MB
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginTop: 4 }}>
              {['JPG', 'PNG', 'WEBP', 'GIF', 'MP4', 'MOV', 'WEBM'].map(ext => (
                <span key={ext} style={{
                  fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)',
                  border: '1px solid var(--border)', borderRadius: 2, padding: '1px 5px',
                }}>
                  {ext}
                </span>
              ))}
            </div>
          </div>
        ) : (
          /* File preview */
          <div style={{ display: 'flex', gap: 14, padding: 14, alignItems: 'flex-start' }}>
            {/* Thumbnail */}
            <div style={{
              width: 80, height: 80, borderRadius: 6, overflow: 'hidden',
              flexShrink: 0, background: 'var(--bg)', border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {preview && !isVideo(file) ? (
                <img src={preview} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : preview && isVideo(file) ? (
                <video src={preview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} muted />
              ) : (
                <span style={{ fontSize: 28 }}>{isVideo(file) ? '🎬' : '🖼'}</span>
              )}
            </div>

            {/* File info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13,
                color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              }}>
                {file.name}
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', marginTop: 3 }}>
                {formatBytes(file.size)} · {file.type.split('/')[1].toUpperCase()}
              </div>

              {/* Gemini badge */}
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 5, marginTop: 8,
                background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.25)',
                borderRadius: 4, padding: '4px 8px',
              }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#7c3aed', boxShadow: '0 0 6px #7c3aed' }} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#a78bfa', letterSpacing: '0.08em' }}>
                  GEMINI VISION WILL ANALYZE
                </span>
              </div>

              <div style={{ marginTop: 6, fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', lineHeight: 1.5 }}>
                Visual content will be analyzed and woven into every platform adaptation
              </div>
            </div>

            {/* Remove button */}
            <button
              onClick={clearFile}
              title="Remove file"
              style={{
                background: 'rgba(255,107,53,0.1)', border: '1px solid rgba(255,107,53,0.2)',
                borderRadius: 4, color: 'var(--accent2)', width: 28, height: 28,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', fontSize: 14, flexShrink: 0,
              }}
            >
              ×
            </button>
          </div>
        )}
      </div>

      {error && (
        <div style={{
          marginTop: 6, fontFamily: 'var(--font-mono)', fontSize: 10,
          color: 'var(--accent2)', padding: '6px 10px',
          background: 'rgba(255,107,53,0.06)', border: '1px solid rgba(255,107,53,0.2)',
          borderRadius: 4,
        }}>
          ⚠ {error}
        </div>
      )}

      {!file && (
        <div style={{
          marginTop: 6, fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)',
          lineHeight: 1.6, padding: '6px 0',
        }}>
          Upload a photo, video, or reel — Gemini Vision will analyze its visual content and tailor every platform's caption, hook, blueprint, and hashtags around it.
        </div>
      )}
    </div>
  )
}
