import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Header({ currentPage, onNavigate }) {
  const { user, logout } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header style={{
      borderBottom: '1px solid var(--border)', padding: '0 32px', height: 64,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      position: 'sticky', top: 0,
      background: 'rgba(8,8,8,0.95)', backdropFilter: 'blur(12px)', zIndex: 100,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }} onClick={() => onNavigate('home')}>
        <div style={{
          width: 32, height: 32, background: 'var(--accent)',
          clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)', flexShrink: 0,
        }} />
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, letterSpacing: '-0.02em', lineHeight: 1 }}>OMNICHANNEL</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.15em' }}>ORCHESTRATION ENGINE</div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <nav style={{ display: 'flex', gap: 2 }}>
          {[{ id: 'home', label: 'Orchestrate' }, { id: 'accounts', label: 'Accounts' }, { id: 'history', label: 'History' }].map(nav => (
            <button key={nav.id} onClick={() => onNavigate(nav.id)} style={{
              background: currentPage === nav.id ? 'var(--bg3)' : 'transparent',
              border: currentPage === nav.id ? '1px solid var(--border)' : '1px solid transparent',
              borderRadius: 6, padding: '6px 14px',
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12,
              color: currentPage === nav.id ? 'var(--text)' : 'var(--text3)',
              cursor: 'pointer', transition: 'all 0.15s',
            }}>
              {nav.label}
            </button>
          ))}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '0 12px', borderLeft: '1px solid var(--border)' }}>
          <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 8px var(--accent)' }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em' }}>ONLINE</span>
        </div>

        {user && (
          <div style={{ position: 'relative' }}>
            <button onClick={() => setMenuOpen(m => !m)} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '4px 10px 4px 4px',
              background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 100,
              cursor: 'pointer', transition: 'all 0.15s',
            }}>
              {user.picture
                ? <img src={user.picture} alt="" style={{ width: 28, height: 28, borderRadius: '50%' }} />
                : <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: '#000' }}>{user.name?.[0] || '?'}</div>
              }
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, fontWeight: 600, color: 'var(--text)' }}>
                {user.name?.split(' ')[0]}
              </span>
              <span style={{ color: 'var(--text3)', fontSize: 10 }}>▾</span>
            </button>

            {menuOpen && (
              <div style={{
                position: 'absolute', top: 'calc(100% + 8px)', right: 0, zIndex: 200,
                background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8,
                minWidth: 200, overflow: 'hidden', boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
              }}>
                <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13 }}>{user.name}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', marginTop: 2 }}>{user.email}</div>
                </div>
                <div style={{ padding: '6px' }}>
                  {[
                    { icon: '🔗', label: 'Connected Accounts', action: () => { onNavigate('accounts'); setMenuOpen(false) }, color: 'var(--text)' },
                    { icon: '📋', label: 'History & Scheduled', action: () => { onNavigate('history'); setMenuOpen(false) }, color: 'var(--text)' },
                    { icon: '↩', label: 'Sign Out', action: () => { logout(); setMenuOpen(false) }, color: 'var(--accent2)' },
                  ].map(item => (
                    <button key={item.label} onClick={item.action} style={{
                      width: '100%', textAlign: 'left', padding: '8px 10px',
                      background: 'transparent', border: 'none', borderRadius: 4,
                      fontFamily: 'var(--font-display)', fontSize: 13, color: item.color, cursor: 'pointer',
                    }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                    >
                      {item.icon} {item.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  )
}
