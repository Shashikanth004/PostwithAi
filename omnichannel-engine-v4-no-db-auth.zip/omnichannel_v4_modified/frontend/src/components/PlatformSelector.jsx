import React from 'react'
import { PLATFORMS } from '../utils/constants'

export default function PlatformSelector({ selected, onChange }) {
  const toggle = (id) => {
    if (selected.includes(id)) {
      onChange(selected.filter(p => p !== id))
    } else {
      onChange([...selected, id])
    }
  }

  const selectAll = () => onChange(PLATFORMS.map(p => p.id))
  const clearAll = () => onChange([])

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <label style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
          Target Platforms — {selected.length} selected
        </label>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={selectAll} style={btnStyle}>ALL</button>
          <button onClick={clearAll} style={btnStyle}>CLEAR</button>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
        gap: 8,
      }}>
        {PLATFORMS.map(p => {
          const active = selected.includes(p.id)
          return (
            <button
              key={p.id}
              onClick={() => toggle(p.id)}
              style={{
                background: active ? p.bg : 'var(--bg3)',
                border: `1px solid ${active ? p.color : 'var(--border)'}`,
                borderRadius: 'var(--radius2)',
                padding: '10px 12px',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                transition: 'all 0.15s',
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {active && (
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0,
                  height: 2, background: p.color,
                  boxShadow: `0 0 8px ${p.color}`,
                }} />
              )}
              <span style={{ fontSize: 16 }}>{p.icon}</span>
              <span style={{
                fontFamily: 'var(--font-display)', fontWeight: 600,
                fontSize: 12, color: active ? 'var(--text)' : 'var(--text2)',
                textAlign: 'left', lineHeight: 1.2,
              }}>
                {p.label}
              </span>
              {active && (
                <div style={{
                  marginLeft: 'auto', width: 6, height: 6, borderRadius: '50%',
                  background: p.color, boxShadow: `0 0 6px ${p.color}`,
                  flexShrink: 0,
                }} />
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}

const btnStyle = {
  background: 'transparent',
  border: '1px solid var(--border)',
  borderRadius: 'var(--radius)',
  color: 'var(--text3)',
  fontFamily: 'var(--font-mono)',
  fontSize: 9,
  letterSpacing: '0.1em',
  padding: '3px 8px',
  cursor: 'pointer',
  transition: 'all 0.15s',
}
