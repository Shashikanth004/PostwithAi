import React, { useState } from 'react'
import PlatformCard from './PlatformCard'
import PostNowPanel from './PostNowPanel'
import { PLATFORMS } from '../utils/constants'

export default function ResultsPanel({ data, onReset }) {
  const [view, setView] = useState('grid')
  const payload   = data.scheduled_payload || {}
  const platforms = Object.keys(payload)
  const schedules = data.schedules || {}
  const hasAnySchedule = Object.values(schedules).some(Boolean)
  const fullJSON  = JSON.stringify({ scheduled_payload: payload }, null, 2)

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 10px var(--accent)' }} />
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20 }}>Scheduled Payload</h2>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4, flexWrap: 'wrap' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.08em' }}>
              {platforms.length} platforms · Generated {data.generated_at?.slice(0, 19)?.replace('T', ' ')} UTC
            </span>
            {data.media_analyzed && (
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#a78bfa', background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.25)', borderRadius: 3, padding: '2px 7px', letterSpacing: '0.08em' }}>◆ GEMINI VISION</span>
            )}
            {hasAnySchedule && (
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent)', background: 'rgba(200,255,0,0.08)', border: '1px solid rgba(200,255,0,0.2)', borderRadius: 3, padding: '2px 7px', letterSpacing: '0.08em' }}>📅 SCHEDULED</span>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 1, border: '1px solid var(--border)', borderRadius: 4, overflow: 'hidden' }}>
            {['grid', 'timeline', 'json'].map(v => (
              <button key={v} onClick={() => setView(v)} style={{
                background: view === v ? 'var(--border2)' : 'transparent', border: 'none',
                color: view === v ? 'var(--text)' : 'var(--text3)',
                fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.1em',
                padding: '6px 12px', cursor: 'pointer', textTransform: 'uppercase',
              }}>{v}</button>
            ))}
          </div>
          <button onClick={onReset} style={{ background: 'transparent', border: '1px solid var(--border)', borderRadius: 4, color: 'var(--text2)', fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.1em', padding: '6px 14px', cursor: 'pointer' }}>
            ← NEW
          </button>
        </div>
      </div>

      {/* TIMELINE VIEW */}
      {view === 'timeline' && (
        <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', background: 'var(--bg3)', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Publishing Schedule</div>
          <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 0 }}>
            {[...platforms].sort((a, b) => {
              const da = schedules[a] ? new Date(schedules[a]) : new Date(9e15)
              const db = schedules[b] ? new Date(schedules[b]) : new Date(9e15)
              return da - db
            }).map((p, i, arr) => {
              const meta = PLATFORMS.find(pl => pl.id === p)
              const dt = schedules[p] ? new Date(schedules[p]) : null
              return (
                <div key={p} style={{ display: 'flex', gap: 16, paddingBottom: i === arr.length - 1 ? 0 : 20, position: 'relative' }}>
                  {i < arr.length - 1 && <div style={{ position: 'absolute', left: 15, top: 30, bottom: 0, width: 1, background: 'var(--border)' }} />}
                  <div style={{ width: 30, height: 30, borderRadius: '50%', flexShrink: 0, background: dt ? meta?.bg || 'var(--bg3)' : 'var(--bg3)', border: `2px solid ${dt ? meta?.color || 'var(--border2)' : 'var(--border)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, zIndex: 1, boxShadow: dt ? `0 0 10px ${meta?.color}44` : 'none' }}>
                    {meta?.icon}
                  </div>
                  <div style={{ flex: 1, paddingTop: 4 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: meta?.color }}>{meta?.label}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{payload[p]?.format}</span>
                    </div>
                    {dt ? (
                      <div style={{ marginTop: 4, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text)' }}>{dt.toLocaleString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: 'var(--accent)', background: 'rgba(200,255,0,0.08)', border: '1px solid rgba(200,255,0,0.2)', borderRadius: 4, padding: '1px 8px' }}>
                          {dt.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })}
                        </span>
                      </div>
                    ) : (
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>⚡ Post immediately</div>
                    )}
                    {payload[p]?.hook && (
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--text2)', marginTop: 4, fontStyle: 'italic', lineHeight: 1.4 }}>
                        "{payload[p].hook.slice(0, 80)}{payload[p].hook.length > 80 ? '…' : ''}"
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* JSON VIEW */}
      {view === 'json' && (
        <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'auto', maxHeight: '70vh' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 16px', borderBottom: '1px solid var(--border)', background: 'var(--bg3)' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.1em' }}>scheduled_payload.json</span>
            <button onClick={() => navigator.clipboard.writeText(fullJSON)} style={{ background: 'transparent', border: '1px solid var(--border)', borderRadius: 2, color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', padding: '3px 8px', cursor: 'pointer' }}>
              COPY JSON
            </button>
          </div>
          <pre style={{ padding: 20, fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text2)', lineHeight: 1.7, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
            {fullJSON}
          </pre>
        </div>
      )}

      {/* GRID VIEW */}
      {view === 'grid' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(480px, 1fr))', gap: 16 }}>
          {platforms.map((platformId, i) => (
            <PlatformCard key={platformId} platformId={platformId} data={payload[platformId]} scheduledAt={schedules[platformId]} index={i} />
          ))}
        </div>
      )}

      {/* Post Now / Schedule Panel — always visible below results */}
      <PostNowPanel
        scheduledPayload={payload}
        schedules={schedules}
        mediaUrl={data.media_url || null}
      />
    </div>
  )
}
