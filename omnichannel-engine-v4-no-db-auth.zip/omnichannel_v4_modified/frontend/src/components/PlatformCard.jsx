import React, { useState } from 'react'
import { PLATFORMS, REACH_COLORS } from '../utils/constants'

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <button onClick={copy} style={{
      background: 'transparent', border: '1px solid var(--border)',
      borderRadius: 2, color: copied ? 'var(--accent)' : 'var(--text3)',
      fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em',
      padding: '3px 8px', cursor: 'pointer', transition: 'all 0.15s',
    }}>
      {copied ? '✓ COPIED' : 'COPY'}
    </button>
  )
}

function Field({ label, children, copyText }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
          {label}
        </span>
        {copyText && <CopyBtn text={copyText} />}
      </div>
      {children}
    </div>
  )
}

function Pill({ text, color }) {
  return (
    <span style={{
      display: 'inline-block', padding: '2px 8px',
      border: `1px solid ${color || 'var(--border2)'}`,
      borderRadius: 100, fontFamily: 'var(--font-mono)', fontSize: 10,
      color: color || 'var(--text2)', margin: '2px', lineHeight: 1.6,
    }}>
      {text}
    </span>
  )
}

export default function PlatformCard({ platformId, data, index, scheduledAt }) {
  const [expanded, setExpanded] = useState(true)
  const meta = PLATFORMS.find(p => p.id === platformId) || {
    label: platformId, icon: '📱', color: '#888', bg: '#111',
  }
  const reach = data.estimated_reach
  const reachColor = REACH_COLORS[reach] || 'var(--text3)'
  const isVideo = data.format === 'video'
  const isThread = data.format === 'thread'

  return (
    <div
      className="fade-up"
      style={{
        animationDelay: `${index * 60}ms`,
        border: `1px solid var(--border)`,
        borderRadius: 8,
        overflow: 'hidden',
        background: 'var(--bg2)',
        transition: 'border-color 0.2s',
      }}
    >
      {/* Card header */}
      <div
        onClick={() => setExpanded(e => !e)}
        style={{
          display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px',
          cursor: 'pointer', borderBottom: expanded ? '1px solid var(--border)' : 'none',
          background: meta.bg, userSelect: 'none',
          borderTop: `3px solid ${meta.color}`,
        }}
      >
        <span style={{ fontSize: 20 }}>{meta.icon}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: meta.color, fontFamily: 'var(--font-display)' }}>
            {meta.label}
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em', marginTop: 2 }}>
            {data.format?.toUpperCase()}{scheduledAt ? ` · 📅 ${new Date(scheduledAt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}` : data.best_post_time ? ` · ${data.best_post_time}` : ''}
          </div>
        </div>
        {reach && (
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em' }}>REACH</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: reachColor, fontWeight: 700, textTransform: 'uppercase' }}>
              {reach}
            </div>
          </div>
        )}
        <div style={{ color: 'var(--text3)', fontSize: 12, marginLeft: 8 }}>
          {expanded ? '▲' : '▼'}
        </div>
      </div>

      {/* Card body */}
      {expanded && (
        <div style={{ padding: '18px' }}>

          {/* Hook */}
          {data.hook && (
            <Field label="Hook" copyText={data.hook}>
              <div style={{
                background: 'rgba(200,255,0,0.05)', border: '1px solid rgba(200,255,0,0.15)',
                borderRadius: 4, padding: '10px 12px',
                fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700,
                color: 'var(--accent)', lineHeight: 1.4,
              }}>
                {data.hook}
              </div>
            </Field>
          )}

          {/* Media Usage Tip */}
          {data.media_usage_tip && (
            <Field label="📎 Media Usage Tip">
              <div style={{
                background: 'rgba(124,58,237,0.06)', border: '1px solid rgba(124,58,237,0.2)',
                borderRadius: 4, padding: '10px 12px',
                fontFamily: 'var(--font-display)', fontSize: 13, color: '#c4b5fd',
                lineHeight: 1.6,
              }}>
                {data.media_usage_tip}
              </div>
            </Field>
          )}

          {/* Caption */}
          {data.caption && !isThread && (
            <Field label="Caption" copyText={data.caption}>
              <div style={{
                background: 'var(--bg3)', borderRadius: 4, padding: '12px',
                fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--text)',
                lineHeight: 1.7, whiteSpace: 'pre-wrap',
              }}>
                {data.caption}
              </div>
            </Field>
          )}

          {/* Thread tweets */}
          {isThread && data.thread_tweets && (
            <Field label={`Thread — ${data.thread_tweets.length} tweets`} copyText={data.thread_tweets.join('\n\n---\n\n')}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {data.thread_tweets.map((tweet, i) => (
                  <div key={i} style={{
                    background: 'var(--bg3)', borderRadius: 4, padding: '10px 12px',
                    display: 'flex', gap: 10,
                  }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', minWidth: 20 }}>
                      {i + 1}/
                    </span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--text)', lineHeight: 1.6 }}>
                      {tweet}
                    </span>
                  </div>
                ))}
              </div>
            </Field>
          )}

          {/* Video blueprint */}
          {isVideo && data.video_rendering_blueprint && (
            <Field label="Video Rendering Blueprint">
              <div style={{
                background: 'rgba(124,58,237,0.06)', border: '1px solid rgba(124,58,237,0.2)',
                borderRadius: 6, padding: 14, display: 'flex', flexDirection: 'column', gap: 12,
              }}>
                {data.video_rendering_blueprint.visual_instructions && (
                  <div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#7c3aed', marginBottom: 4, letterSpacing: '0.1em' }}>VISUAL DIRECTION</div>
                    <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.6 }}>
                      {data.video_rendering_blueprint.visual_instructions}
                    </div>
                  </div>
                )}
                {data.video_rendering_blueprint.on_screen_text?.length > 0 && (
                  <div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#7c3aed', marginBottom: 6, letterSpacing: '0.1em' }}>ON-SCREEN TEXT</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {data.video_rendering_blueprint.on_screen_text.map((t, i) => (
                        <div key={i} style={{
                          background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(124,58,237,0.3)',
                          borderRadius: 3, padding: '6px 10px',
                          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: '#fff',
                          display: 'flex', gap: 8, alignItems: 'center',
                        }}>
                          <span style={{ color: '#7c3aed', fontFamily: 'var(--font-mono)', fontSize: 9 }}>T{i + 1}</span>
                          {t}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {data.video_rendering_blueprint.audio_track_directive && (
                  <div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#7c3aed', marginBottom: 4, letterSpacing: '0.1em' }}>🎵 AUDIO DIRECTIVE</div>
                    <div style={{ fontSize: 13, color: 'var(--text2)' }}>
                      {data.video_rendering_blueprint.audio_track_directive}
                    </div>
                  </div>
                )}
                {data.video_rendering_blueprint.duration_seconds && (
                  <div style={{ display: 'flex', gap: 16 }}>
                    <div>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#7c3aed' }}>DURATION: </span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text)' }}>
                        {data.video_rendering_blueprint.duration_seconds}s
                      </span>
                    </div>
                    {data.video_rendering_blueprint.transitions && (
                      <div>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#7c3aed' }}>TRANSITIONS: </span>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text)' }}>
                          {data.video_rendering_blueprint.transitions}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Field>
          )}

          {/* CTA */}
          {data.cta && (
            <Field label="Call to Action" copyText={data.cta}>
              <div style={{
                background: 'var(--bg3)', borderRadius: 4, padding: '8px 12px',
                fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--accent2)',
              }}>
                👉 {data.cta}
              </div>
            </Field>
          )}

          {/* Hashtags */}
          {data.hashtags?.length > 0 && (
            <Field label={`Hashtags (${data.hashtags.length})`} copyText={data.hashtags.join(' ')}>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {data.hashtags.map((tag, i) => (
                  <Pill key={i} text={tag} color={meta.color} />
                ))}
              </div>
            </Field>
          )}
        </div>
      )}
    </div>
  )
}
