import React, { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext(null)

/**
 * Decode a JWT payload without verifying (client-side display only).
 * Verification happens server-side on every API call.
 */
function decodeJwtPayload(token) {
  try {
    const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
    return JSON.parse(atob(base64))
  } catch {
    return null
  }
}

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null)
  const [token, setToken]     = useState(() => localStorage.getItem('omni_token'))
  const [loading, setLoading] = useState(true)

  // On mount: if a token exists, decode the user from it directly — no DB call needed
  useEffect(() => {
    if (!token) { setLoading(false); return }

    const payload = decodeJwtPayload(token)
    if (!payload || (payload.exp && payload.exp * 1000 < Date.now())) {
      // Token missing or expired — clear it
      localStorage.removeItem('omni_token')
      setToken(null)
      setLoading(false)
      return
    }

    setUser({
      google_id: payload.sub,
      email:     payload.email  || '',
      name:      payload.name   || '',
      picture:   payload.picture || '',
    })
    setLoading(false)
  }, [token])

  const loginWithGoogle = () => {
    window.location.href = '/api/auth/google/login'
  }

  const handleCallback = (newToken) => {
    const payload = decodeJwtPayload(newToken)
    if (payload) {
      localStorage.setItem('omni_token', newToken)
      setToken(newToken)
      setUser({
        google_id: payload.sub,
        email:     payload.email   || '',
        name:      payload.name    || '',
        picture:   payload.picture || '',
      })
    }
  }

  const logout = () => {
    localStorage.removeItem('omni_token')
    setToken(null)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, token, loading, loginWithGoogle, handleCallback, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
