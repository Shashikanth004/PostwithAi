import React, { useEffect } from 'react'
import { useAuth } from '../context/AuthContext'

export default function AuthCallback() {
  const { handleCallback } = useAuth()

  useEffect(() => {
    // Token is in the URL fragment (#token=...) — never in query params (avoids server logs)
    const hash = window.location.hash
    const token = new URLSearchParams(hash.replace('#', '?')).get('token')
    if (token) {
      handleCallback(token)
      window.location.href = '/'
    } else {
      window.location.href = '/?auth_error=1'
    }
  }, [])

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexDirection: 'column', gap: 16,
    }}>
      <div style={{
        width: 40, height: 40, borderRadius: '50%',
        border: '2px solid transparent', borderTopColor: 'var(--accent)',
        animation: 'spin 1s linear infinite',
      }} />
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text3)', letterSpacing: '0.1em' }}>
        AUTHENTICATING...
      </div>
    </div>
  )
}
