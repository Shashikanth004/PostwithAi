import React, { useState, useEffect } from 'react'
import { api } from '../utils/api'
import { PLATFORMS } from '../utils/constants'

export default function HistoryPage() {
  const [history, setHistory]     = useState([])
  const [scheduled, setScheduled] = useState([])
  const [tab, setTab]             = useState('history')
  const [loading, setLoading]     = useState(true)
  const [cancelling, setCancelling] = useState(null)

  useEffect(() => {
    Promise.all([
      api.get('/history').then(r => setHistory(r.data.history || [])),
      api.get('/posts/scheduled').then(r => setScheduled(r.data.scheduled || [])),
    ]).finally(() => setLoading(false))
  }, [])

  const cancelPost = async (id) => {
    if (!confirm('Cancel this scheduled post?')) return
    setCancelling(id)
    try {
      await api.delete(`/posts/scheduled/${id}`)
      setScheduled(prev => prev.filter(p => p.id !== id))
    } catch (e) {
      alert('Failed to cancel: ' + (e?.response?.data?.detail || e.message))
    } finally { setCancelling(null) }
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 80px' }}>
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent)', letterSpacing: '0.2em', marginBottom: 10 }}>◆ ACTIVITY</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 32, letterSpacing: '-0.03em' }}>History & Scheduled</h1>
        <p style={{ color: 'var(--text2)', fontSize: 14, marginTop: 8, lineHeight: 1.6 }}>
          Your past orchestrations and upcoming scheduled posts.
        </p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 1, border: '1px solid var(--border)', borderRadius: 6, overflow: 'hidden', marginBottom: 24, width: 'fit-content' }}>
        {[
          { id: 'history',   label: `Orchestration History (${history.length})` },
          { id: 'scheduled', label: `Scheduled Posts (${scheduled.length})` },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: tab === t.id ? 'var(--border2)' : 'transparent',
            border: 'none', color: tab === t.id ? 'var(--text)' : 'var(--text3)',
            fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.08em',
            padding: '8px 16px', cursor: 'pointer', textTransform: 'uppercase',
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[1,2,3].map(i => (
            <div key={i} style={{ height: 72, borderRadius: 8, background: 'var(--bg2)', border: '1px solid var(--border)' }} />
          ))}
        </div>
      ) : tab === 'history' ? (
        history.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>
            No orchestrations yet. Go generate some content!
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {history.map((h, i) => (
              <div key={i} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, padding: '14px 18px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600, color: 'var(--text)', lineHeight: 1.4, marginBottom: 6 }}>
                      {h.base_content?.slice(0, 100)}{h.base_content?.length > 100 ? '…' : ''}
                    </div>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {(h.platforms || []).map(p => {
                        const meta = PLATFORMS.find(pl => pl.id === p)
                        return (
                          <span key={p} style={{ fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 4, background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 4, padding: '2px 6px' }}>
                            {meta?.icon} <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: meta?.color }}>{meta?.label || p}</span>
                          </span>
                        )
                      })}
                      {h.media_analyzed && (
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#a78bfa', background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.2)', borderRadius: 4, padding: '2px 6px' }}>
                          ◆ VISION
                        </span>
                      )}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)' }}>
                      {new Date(h.generated_at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                    </div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', marginTop: 2 }}>
                      {h.niche} · {h.brand_voice}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        scheduled.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>
            No scheduled posts. Generate content and schedule it from the results panel.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {scheduled.map(post => {
              const meta = PLATFORMS.find(p => p.id === post.platform)
              const dt = new Date(post.scheduled_at)
              const isPast = dt < new Date()
              return (
                <div key={post.id} style={{
                  background: 'var(--bg2)', border: `1px solid ${isPast ? 'rgba(255,107,53,0.3)' : 'var(--border)'}`,
                  borderRadius: 8, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14,
                }}>
                  <div style={{ fontSize: 20, flexShrink: 0 }}>{meta?.icon}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: meta?.color }}>{meta?.label}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: isPast ? 'var(--accent2)' : 'var(--accent)', background: isPast ? 'rgba(255,107,53,0.08)' : 'rgba(200,255,0,0.06)', border: `1px solid ${isPast ? 'rgba(255,107,53,0.2)' : 'rgba(200,255,0,0.15)'}`, borderRadius: 3, padding: '1px 6px' }}>
                        {isPast ? 'OVERDUE' : 'PENDING'}
                      </span>
                    </div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--text2)', lineHeight: 1.4, marginBottom: 4 }}>
                      {post.payload?.caption?.slice(0, 80)}{post.payload?.caption?.length > 80 ? '…' : ''}
                    </div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: isPast ? 'var(--accent2)' : 'var(--accent)', fontWeight: 700 }}>
                      📅 {dt.toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                    </div>
                  </div>
                  <button
                    onClick={() => cancelPost(post.id)}
                    disabled={cancelling === post.id}
                    style={{
                      background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.2)',
                      borderRadius: 6, padding: '6px 12px', flexShrink: 0,
                      fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent2)',
                      cursor: 'pointer', letterSpacing: '0.08em',
                      opacity: cancelling === post.id ? 0.5 : 1,
                    }}
                  >
                    {cancelling === post.id ? '...' : 'CANCEL'}
                  </button>
                </div>
              )
            })}
          </div>
        )
      )}
    </div>
  )
}
