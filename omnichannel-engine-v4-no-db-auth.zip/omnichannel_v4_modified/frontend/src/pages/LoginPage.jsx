import React from 'react'
import { useAuth } from '../context/AuthContext'

export default function LoginPage() {
  const { loginWithGoogle } = useAuth()

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      {/* Background grid */}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 0,
        backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
        backgroundSize: '48px 48px', opacity: 0.3,
      }} />

      <div style={{
        position: 'relative', zIndex: 1,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 32,
        padding: '48px 40px', maxWidth: 440, width: '100%',
        background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 16,
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 48, height: 48, background: 'var(--accent)',
            clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)',
          }} />
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, letterSpacing: '-0.03em' }}>
              OMNICHANNEL
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.2em' }}>
              ORCHESTRATION ENGINE
            </div>
          </div>
        </div>

        {/* Tagline */}
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, lineHeight: 1.3 }}>
            One idea.
            <span style={{ color: 'var(--accent)' }}> Every platform.</span>
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--text2)', marginTop: 8, lineHeight: 1.6 }}>
            Sign in to connect your social accounts, schedule posts, and orchestrate content across 10 platforms with Gemini AI.
          </div>
        </div>

        {/* Feature list */}
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { icon: '🔗', text: 'Connect LinkedIn, X, Instagram, TikTok, Pinterest, YouTube' },
            { icon: '🤖', text: 'Gemini Vision analyzes your photos and videos' },
            { icon: '📅', text: 'Schedule posts per platform with optimal times' },
            { icon: '⚡', text: 'Platform-native content — not just reposts' },
          ].map(f => (
            <div key={f.icon} style={{
              display: 'flex', gap: 10, alignItems: 'flex-start',
              background: 'var(--bg3)', border: '1px solid var(--border)',
              borderRadius: 8, padding: '8px 12px',
            }}>
              <span style={{ fontSize: 14, flexShrink: 0 }}>{f.icon}</span>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--text2)', lineHeight: 1.4 }}>
                {f.text}
              </span>
            </div>
          ))}
        </div>

        {/* Google Sign-In button */}
        <button
          onClick={loginWithGoogle}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
            gap: 12, padding: '14px 24px',
            background: '#fff', border: '1px solid #ddd', borderRadius: 8,
            cursor: 'pointer', transition: 'all 0.15s',
            fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 15, color: '#333',
          }}
          onMouseEnter={e => e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.3)'}
          onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
        >
          {/* Google G logo */}
          <svg width="20" height="20" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          Continue with Google
        </button>

        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', textAlign: 'center', lineHeight: 1.6 }}>
          We never store your Google account data in our servers.<br />Your identity lives only in a signed token on your device.
        </div>
      </div>
    </div>
  )
}
