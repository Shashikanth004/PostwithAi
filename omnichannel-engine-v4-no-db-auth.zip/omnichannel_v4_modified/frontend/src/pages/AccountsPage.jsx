import React, { useState, useEffect, useCallback } from 'react'
import { getSocialAccounts, disconnectAccount, getConnectUrl } from '../utils/api'
import { useAuth } from '../context/AuthContext'

const CONNECTABLE_PLATFORMS = [
  { id: 'linkedin',  label: 'LinkedIn',           icon: '💼', color: '#0A66C2', bg: '#000d1a', desc: 'Share professional posts, articles & updates' },
  { id: 'x',        label: 'X (Twitter)',         icon: '𝕏',  color: '#e7e9ea', bg: '#0d0d0d', desc: 'Post tweets and threads' },
  { id: 'instagram', label: 'Instagram / Facebook', icon: '📸', color: '#E1306C', bg: '#1a0a10', desc: 'Publish feed posts, reels & stories' },
  { id: 'tiktok',   label: 'TikTok',              icon: '🎵', color: '#69C9D0', bg: '#001214', desc: 'Upload short-form videos & reels' },
  { id: 'pinterest', label: 'Pinterest',           icon: '📌', color: '#E60023', bg: '#1a0005', desc: 'Create pins and boards' },
  { id: 'youtube',  label: 'YouTube',             icon: '🎬', color: '#FF0000', bg: '#1a0000', desc: 'Upload videos & Shorts' },
]

function StatusDot({ connected }) {
  return (
    <div style={{
      width: 8, height: 8, borderRadius: '50%',
      background: connected ? 'var(--accent)' : 'var(--text3)',
      boxShadow: connected ? '0 0 8px var(--accent)' : 'none',
      flexShrink: 0,
    }} />
  )
}

export default function AccountsPage() {
  const { user } = useAuth()
  const [accounts, setAccounts]     = useState([])
  const [loading, setLoading]       = useState(true)
  const [disconnecting, setDisconnecting] = useState(null)
  const [toast, setToast]           = useState(null)

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  const fetchAccounts = useCallback(async () => {
    try {
      const data = await getSocialAccounts()
      setAccounts(data.accounts || [])
    } catch { setAccounts([]) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => {
    fetchAccounts()
    // If coming back from OAuth callback with ?connected=platform
    const params = new URLSearchParams(window.location.search)
    const connected = params.get('connected')
    if (connected) {
      showToast(`✓ ${connected} connected successfully!`)
      window.history.replaceState({}, '', '/accounts')
    }
  }, [fetchAccounts])

  const handleConnect = (platformId) => {
    // Redirect to backend OAuth flow (preserves session)
    window.location.href = getConnectUrl(platformId)
  }

  const handleDisconnect = async (platformId, platformLabel) => {
    if (!confirm(`Disconnect ${platformLabel}? You can reconnect anytime.`)) return
    setDisconnecting(platformId)
    try {
      await disconnectAccount(platformId)
      setAccounts(prev => prev.filter(a => a.platform !== platformId))
      showToast(`${platformLabel} disconnected.`, 'info')
    } catch (e) {
      showToast(`Failed to disconnect: ${e.message}`, 'error')
    } finally { setDisconnecting(null) }
  }

  const getAccount = (platformId) => accounts.find(a => a.platform === platformId)
  const connectedCount = accounts.length

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 80px' }}>

      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', top: 80, right: 24, zIndex: 1000,
          background: toast.type === 'error' ? 'rgba(255,107,53,0.12)' : 'rgba(200,255,0,0.1)',
          border: `1px solid ${toast.type === 'error' ? 'rgba(255,107,53,0.4)' : 'rgba(200,255,0,0.35)'}`,
          borderRadius: 8, padding: '12px 18px',
          fontFamily: 'var(--font-mono)', fontSize: 11,
          color: toast.type === 'error' ? 'var(--accent2)' : 'var(--accent)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
          animation: 'fadeUp 0.2s ease',
        }}>
          {toast.msg}
        </div>
      )}

      {/* Page header */}
      <div style={{ marginBottom: 40 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent)', letterSpacing: '0.2em', marginBottom: 10 }}>
          ◆ ACCOUNT CONNECTIONS
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 32, letterSpacing: '-0.03em' }}>
          Connected Accounts
        </h1>
        <p style={{ color: 'var(--text2)', fontSize: 14, marginTop: 8, lineHeight: 1.6, maxWidth: 500 }}>
          Connect your social media accounts so the engine can post directly. Tokens are encrypted at rest and never shared.
        </p>

        {/* Stats bar */}
        <div style={{ display: 'flex', gap: 24, marginTop: 20 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 28, color: 'var(--accent)' }}>{connectedCount}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em' }}>CONNECTED</div>
          </div>
          <div style={{ width: 1, background: 'var(--border)' }} />
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 28, color: 'var(--text2)' }}>
              {CONNECTABLE_PLATFORMS.length - connectedCount}
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.1em' }}>AVAILABLE</div>
          </div>
        </div>
      </div>

      {/* Platform cards */}
      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {CONNECTABLE_PLATFORMS.map(p => (
            <div key={p.id} style={{
              height: 80, borderRadius: 10, background: 'var(--bg2)',
              border: '1px solid var(--border)',
              backgroundImage: 'linear-gradient(90deg, transparent 25%, var(--bg3) 50%, transparent 75%)',
              backgroundSize: '200% 100%', animation: 'shimmer 1.5s infinite',
            }} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {CONNECTABLE_PLATFORMS.map(p => {
            const account = getAccount(p.id)
            const isConnected = !!account
            const isDisconnecting = disconnecting === p.id

            return (
              <div key={p.id} style={{
                background: isConnected ? p.bg : 'var(--bg2)',
                border: `1px solid ${isConnected ? p.color + '44' : 'var(--border)'}`,
                borderRadius: 10, padding: '18px 20px',
                display: 'flex', alignItems: 'center', gap: 16,
                transition: 'all 0.2s',
                borderLeft: isConnected ? `3px solid ${p.color}` : '1px solid var(--border)',
              }}>
                {/* Platform icon */}
                <div style={{
                  width: 44, height: 44, borderRadius: 10, flexShrink: 0,
                  background: isConnected ? `${p.color}18` : 'var(--bg3)',
                  border: `1px solid ${isConnected ? p.color + '33' : 'var(--border)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 20,
                }}>
                  {p.icon}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: isConnected ? p.color : 'var(--text)' }}>
                      {p.label}
                    </span>
                    <StatusDot connected={isConnected} />
                  </div>

                  {isConnected ? (
                    <div style={{ marginTop: 4 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        {account.profile_pic && (
                          <img
                            src={account.profile_pic}
                            alt=""
                            style={{ width: 20, height: 20, borderRadius: '50%', border: `1px solid ${p.color}44` }}
                            onError={e => e.target.style.display = 'none'}
                          />
                        )}
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text2)' }}>
                          {account.display_name || 'Connected account'}
                        </span>
                      </div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', marginTop: 2 }}>
                        Connected {new Date(account.connected_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                    </div>
                  ) : (
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                      {p.desc}
                    </div>
                  )}
                </div>

                {/* Action button */}
                {isConnected ? (
                  <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                    <div style={{
                      background: 'rgba(200,255,0,0.08)', border: '1px solid rgba(200,255,0,0.2)',
                      borderRadius: 6, padding: '5px 10px',
                      fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent)',
                      letterSpacing: '0.1em',
                    }}>
                      ✓ ACTIVE
                    </div>
                    <button
                      onClick={() => handleDisconnect(p.id, p.label)}
                      disabled={isDisconnecting}
                      style={{
                        background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.25)',
                        borderRadius: 6, padding: '5px 12px',
                        fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent2)',
                        letterSpacing: '0.1em', cursor: 'pointer',
                        opacity: isDisconnecting ? 0.5 : 1,
                      }}
                    >
                      {isDisconnecting ? '...' : 'DISCONNECT'}
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleConnect(p.id)}
                    style={{
                      background: 'var(--bg3)', border: `1px solid ${p.color}55`,
                      borderRadius: 6, padding: '8px 16px', flexShrink: 0,
                      fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12,
                      color: p.color, cursor: 'pointer', transition: 'all 0.15s',
                      whiteSpace: 'nowrap',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = `${p.color}18`; e.currentTarget.style.borderColor = p.color }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'var(--bg3)'; e.currentTarget.style.borderColor = `${p.color}55` }}
                  >
                    + Connect
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Security note */}
      <div style={{
        marginTop: 32, background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 8, padding: 16, display: 'flex', gap: 12,
      }}>
        <span style={{ fontSize: 18, flexShrink: 0 }}>🔒</span>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, marginBottom: 4 }}>
            Security & Privacy
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: 'var(--text2)', lineHeight: 1.6 }}>
            All OAuth access tokens are encrypted with AES-256 (Fernet) before being stored in MongoDB.
            Your credentials are never logged, never sent to third parties, and are only decrypted in
            server memory at post time. You can disconnect any account at any time.
          </div>
        </div>
      </div>
    </div>
  )
}
