import React, { useState, useRef, useEffect } from 'react'
import { useAuth } from './context/AuthContext'
import Header from './components/Header'
import PlatformSelector from './components/PlatformSelector'
import MediaUploader from './components/MediaUploader'
import ScheduleManager from './components/ScheduleManager'
import LoadingState from './components/LoadingState'
import ResultsPanel from './components/ResultsPanel'
import LoginPage from './pages/LoginPage'
import AuthCallback from './pages/AuthCallback'
import AccountsPage from './pages/AccountsPage'
import HistoryPage from './pages/HistoryPage'
import { orchestrate } from './utils/api'
import { BRAND_VOICES, NICHES } from './utils/constants'

const FIELD_STYLE = {
  background: 'var(--bg3)', border: '1px solid var(--border)',
  borderRadius: 'var(--radius2)', color: 'var(--text)',
  fontFamily: 'var(--font-display)', fontSize: 14,
  padding: '10px 14px', width: '100%', outline: 'none',
  transition: 'border-color 0.15s',
}

function Label({ children }) {
  return (
    <label style={{
      display: 'block', marginBottom: 8,
      fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)',
      letterSpacing: '0.12em', textTransform: 'uppercase',
    }}>
      {children}
    </label>
  )
}

function formatScheduleSummary(schedules) {
  const entries = Object.entries(schedules).filter(([, v]) => v)
  if (!entries.length) return null
  const unique = [...new Set(entries.map(([, v]) => v))]
  if (unique.length === 1) {
    const d = new Date(unique[0])
    return d.toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })
  }
  return `${entries.length} platform-specific schedules`
}

export default function App() {
  const { user, loading: authLoading } = useAuth()
  const [page, setPage] = useState(() => {
    // Detect OAuth callback or accounts route on load
    if (window.location.pathname === '/auth/callback') return 'callback'
    if (window.location.pathname === '/accounts') return 'accounts'
    if (window.location.pathname === '/history') return 'history'
    return 'home'
  })

  // Orchestration state
  const [baseContent, setBaseContent]   = useState('')
  const [mediaFile, setMediaFile]       = useState(null)
  const [platforms, setPlatforms]       = useState(['tiktok', 'linkedin', 'x', 'instagram_reels'])
  const [brandVoice, setBrandVoice]     = useState(BRAND_VOICES[0])
  const [niche, setNiche]               = useState('general')
  const [schedules, setSchedules]       = useState({})
  const [liveTrends, setLiveTrends]     = useState('')
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [loading, setLoading]           = useState(false)
  const [result, setResult]             = useState(null)
  const [error, setError]               = useState(null)
  const resultsRef                      = useRef(null)

  const hasContent = baseContent.trim() || mediaFile
  const scheduleSummary = formatScheduleSummary(schedules)

  const buildScheduledTimeString = () => {
    const entries = Object.entries(schedules).filter(([, v]) => v)
    if (!entries.length) return 'Immediate'
    const unique = [...new Set(entries.map(([, v]) => v))]
    if (unique.length === 1) return `All: ${new Date(unique[0]).toUTCString()}`
    return entries.map(([p, v]) => `${p}: ${new Date(v).toUTCString()}`).join(' | ')
  }

  const handleSubmit = async () => {
    if (!hasContent) { setError('Add text content or upload a media file.'); return }
    if (!platforms.length) { setError('Select at least one platform.'); return }
    setError(null); setLoading(true); setResult(null)
    try {
      const data = await orchestrate({
        base_content: baseContent || `Media file: ${mediaFile?.name}`,
        target_platforms: platforms,
        brand_voice: brandVoice,
        niche,
        scheduled_time: buildScheduledTimeString(),
        live_trends: liveTrends || undefined,
        schedules,
      }, mediaFile)
      setResult({ ...data, schedules })
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || 'Something went wrong.')
    } finally { setLoading(false) }
  }

  const handlePlatformsChange = (newPlatforms) => {
    setPlatforms(newPlatforms)
    const cleaned = {}
    newPlatforms.forEach(p => { if (schedules[p]) cleaned[p] = schedules[p] })
    setSchedules(cleaned)
  }

  const navigate = (p) => {
    setPage(p)
    window.history.pushState({}, '', p === 'home' ? '/' : `/${p}`)
  }

  // Handle browser back/forward
  useEffect(() => {
    const handler = () => {
      const path = window.location.pathname
      if (path === '/accounts') setPage('accounts')
      else if (path === '/history') setPage('history')
      else setPage('home')
    }
    window.addEventListener('popstate', handler)
    return () => window.removeEventListener('popstate', handler)
  }, [])

  if (authLoading) return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', border: '2px solid transparent', borderTopColor: 'var(--accent)', animation: 'spin 1s linear infinite' }} />
    </div>
  )

  if (page === 'callback') return <AuthCallback />
  if (!user) return <LoginPage />

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Header currentPage={page} onNavigate={navigate} />

      {page === 'accounts' ? (
        <AccountsPage />
      ) : page === 'history' ? (
        <HistoryPage />
      ) : (
        <main style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 24px 80px' }}>
          {/* Hero */}
          <div style={{ marginBottom: 48, paddingBottom: 48, borderBottom: '1px solid var(--border)' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent)', letterSpacing: '0.2em', marginBottom: 12 }}>◆ Algorithmic Reach Maximizer</div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(32px, 5vw, 56px)', lineHeight: 1.05, letterSpacing: '-0.03em', maxWidth: 700 }}>
              Transform one idea into<span style={{ color: 'var(--accent)' }}> every platform.</span>
            </h1>
            <p style={{ color: 'var(--text2)', fontSize: 16, marginTop: 16, maxWidth: 560, lineHeight: 1.7 }}>
              Hey {user.name?.split(' ')[0]} 👋 — paste text, upload media, schedule per platform. Gemini Vision analyses your content and architects native adaptations.
            </p>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 20 }}>
              {['Text → All Platforms', 'Photo & Video Analysis', 'Per-Platform Scheduling', 'Gemini Vision', 'Encrypted Account Storage'].map(t => (
                <span key={t} style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', border: '1px solid var(--border)', borderRadius: 100, padding: '3px 10px', color: 'var(--text3)', textTransform: 'uppercase' }}>{t}</span>
              ))}
            </div>
          </div>

          {!result && !loading && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, alignItems: 'start' }}>

              {/* Left */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
                {/* Content input */}
                <div style={{ border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden', background: 'var(--bg2)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', borderBottom: '1px solid var(--border)', background: 'var(--bg3)' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Content Input</span>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {baseContent && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent)', padding: '2px 6px', background: 'rgba(200,255,0,0.08)', borderRadius: 2 }}>TEXT ✓</span>}
                      {mediaFile && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#a78bfa', padding: '2px 6px', background: 'rgba(124,58,237,0.1)', borderRadius: 2 }}>MEDIA ✓</span>}
                    </div>
                  </div>
                  <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
                    <div>
                      <Label>Text / Description</Label>
                      <textarea
                        value={baseContent}
                        onChange={e => setBaseContent(e.target.value)}
                        placeholder={mediaFile ? 'Optional: add context — topic, goal, key message...' : 'Paste your raw idea, post, product description, or concept here...'}
                        rows={5}
                        style={{ ...FIELD_STYLE, resize: 'vertical', borderColor: baseContent ? 'var(--border2)' : 'var(--border)' }}
                        onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                        onBlur={e => e.target.style.borderColor = baseContent ? 'var(--border2)' : 'var(--border)'}
                      />
                      <div style={{ textAlign: 'right', fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', marginTop: 4 }}>{baseContent.length} chars</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text3)', letterSpacing: '0.12em' }}>AND / OR</span>
                      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                    </div>
                    <MediaUploader file={mediaFile} onChange={setMediaFile} />
                  </div>
                </div>

                {/* Schedule */}
                <div style={{ border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden', background: 'var(--bg2)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', borderBottom: '1px solid var(--border)', background: 'var(--bg3)' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Scheduling</span>
                    {scheduleSummary && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--accent)', padding: '2px 6px', background: 'rgba(200,255,0,0.08)', borderRadius: 2 }}>◆ SCHEDULED</span>}
                  </div>
                  <div style={{ padding: 16 }}>
                    <ScheduleManager schedules={schedules} onChange={setSchedules} platforms={platforms} />
                  </div>
                </div>

                <div>
                  <Label>Brand Voice</Label>
                  <select value={brandVoice} onChange={e => setBrandVoice(e.target.value)} style={{ ...FIELD_STYLE, appearance: 'none', cursor: 'pointer' }}>
                    {BRAND_VOICES.map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Content Niche</Label>
                  <select value={niche} onChange={e => setNiche(e.target.value)} style={{ ...FIELD_STYLE, appearance: 'none', cursor: 'pointer' }}>
                    {NICHES.map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>

                <div>
                  <button onClick={() => setShowAdvanced(s => !s)} style={{ background: 'transparent', border: 'none', color: 'var(--text3)', fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.12em', cursor: 'pointer', padding: 0, textTransform: 'uppercase' }}>
                    {showAdvanced ? '▲' : '▼'} Advanced Options
                  </button>
                  {showAdvanced && (
                    <div style={{ marginTop: 16 }}>
                      <Label>Live Trends Override</Label>
                      <textarea value={liveTrends} onChange={e => setLiveTrends(e.target.value)} placeholder="Paste current trending audios, hashtags, formats..." rows={3} style={{ ...FIELD_STYLE, resize: 'vertical' }} />
                    </div>
                  )}
                </div>
              </div>

              {/* Right */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
                <PlatformSelector selected={platforms} onChange={handlePlatformsChange} />

                {error && (
                  <div style={{ background: 'rgba(255,107,53,0.08)', border: '1px solid rgba(255,107,53,0.3)', borderRadius: 6, padding: '12px 16px', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent2)', lineHeight: 1.5 }}>
                    ⚠ {error}
                  </div>
                )}

                {(hasContent || platforms.length > 0) && (
                  <div style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 6, padding: 14, fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text3)', lineHeight: 2 }}>
                    <div style={{ color: 'var(--text2)', marginBottom: 6, fontWeight: 600 }}>Engine pipeline:</div>
                    <div style={{ color: mediaFile ? 'var(--accent)' : 'var(--text3)' }}>{mediaFile ? `✓ Gemini Vision → ${mediaFile.name}` : '○ No media uploaded'}</div>
                    <div style={{ color: baseContent ? 'var(--accent)' : 'var(--text3)' }}>{baseContent ? `✓ Text (${baseContent.length} chars)` : '○ No text'}</div>
                    <div style={{ color: scheduleSummary ? 'var(--accent)' : 'var(--text3)' }}>{scheduleSummary ? `✓ Scheduled: ${scheduleSummary}` : '○ No schedule (immediate)'}</div>
                    {platforms.map(p => (
                      <div key={p} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>◇ {p.replace(/_/g, ' ').toUpperCase()}</span>
                        {schedules[p] && <span style={{ color: 'var(--accent)', fontSize: 9 }}>{new Date(schedules[p]).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}</span>}
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={handleSubmit}
                  disabled={!hasContent || !platforms.length}
                  style={{
                    background: hasContent && platforms.length ? 'var(--accent)' : 'var(--bg3)',
                    border: 'none', borderRadius: 6, color: '#000',
                    fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15,
                    letterSpacing: '-0.01em', padding: '16px 32px',
                    cursor: hasContent && platforms.length ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s', opacity: hasContent && platforms.length ? 1 : 0.4,
                  }}
                >
                  {!hasContent ? 'ADD CONTENT TO CONTINUE'
                    : !platforms.length ? 'SELECT PLATFORMS TO CONTINUE'
                    : mediaFile ? `⚡ ANALYZE + ORCHESTRATE FOR ${platforms.length} PLATFORM${platforms.length !== 1 ? 'S' : ''}`
                    : `⚡ ORCHESTRATE FOR ${platforms.length} PLATFORM${platforms.length !== 1 ? 'S' : ''}`}
                </button>
              </div>
            </div>
          )}

          {loading && <LoadingState platforms={platforms} hasMedia={!!mediaFile} />}
          {result && <div ref={resultsRef}><ResultsPanel data={result} onReset={() => { setResult(null); setError(null); window.scrollTo({ top: 0, behavior: 'smooth' }) }} /></div>}
        </main>
      )}
    </div>
  )
}
