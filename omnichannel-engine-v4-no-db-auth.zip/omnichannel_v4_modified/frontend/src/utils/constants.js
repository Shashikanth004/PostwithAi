export const PLATFORMS = [
  { id: 'tiktok',           label: 'TikTok',            icon: '🎵', type: 'video',     color: '#69C9D0', bg: '#010101' },
  { id: 'instagram_reels',  label: 'IG Reels',           icon: '📸', type: 'video',     color: '#E1306C', bg: '#1a0a10' },
  { id: 'youtube_shorts',   label: 'YT Shorts',          icon: '▶',  type: 'video',     color: '#FF0000', bg: '#1a0000' },
  { id: 'linkedin',         label: 'LinkedIn',           icon: '💼', type: 'text',      color: '#0A66C2', bg: '#000d1a' },
  { id: 'x',                label: 'X',                  icon: '𝕏',  type: 'thread',    color: '#e7e9ea', bg: '#0d0d0d' },
  { id: 'threads',          label: 'Threads',            icon: '🧵', type: 'thread',    color: '#aaaaaa', bg: '#111' },
  { id: 'instagram',        label: 'Instagram',          icon: '📷', type: 'image',     color: '#C13584', bg: '#1a0010' },
  { id: 'pinterest',        label: 'Pinterest',          icon: '📌', type: 'visual',    color: '#E60023', bg: '#1a0005' },
  { id: 'facebook',         label: 'Facebook',           icon: '👥', type: 'community', color: '#1877F2', bg: '#00061a' },
  { id: 'youtube',          label: 'YouTube',            icon: '🎬', type: 'video',     color: '#FF0000', bg: '#1a0000' },
]

export const BRAND_VOICES = [
  'professional yet engaging',
  'casual and witty',
  'authoritative expert',
  'inspirational coach',
  'edgy and provocative',
  'educational and clear',
  'friendly and relatable',
]

export const NICHES = [
  'general', 'tech & startups', 'fitness & wellness', 'finance & investing',
  'fashion & beauty', 'food & cooking', 'travel', 'education',
  'entertainment', 'business & entrepreneurship', 'mental health', 'sustainability',
]

export const REACH_COLORS = {
  low: '#666',
  medium: '#f59e0b',
  high: '#22c55e',
  viral: '#c8ff00',
}
