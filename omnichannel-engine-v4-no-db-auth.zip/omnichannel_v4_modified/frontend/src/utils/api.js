import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || '/api'

export const api = axios.create({
  baseURL: API_BASE,
  timeout: 120000,
})

// Inject JWT from localStorage into every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('omni_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

export async function orchestrate(payload, mediaFile) {
  const form = new FormData()
  form.append('base_content', payload.base_content)
  form.append('target_platforms', JSON.stringify(payload.target_platforms))
  form.append('brand_voice', payload.brand_voice || 'professional yet engaging')
  form.append('niche', payload.niche || 'general')
  form.append('live_trends', payload.live_trends || '')
  form.append('scheduled_time', payload.scheduled_time || 'Immediate')
  form.append('schedules', JSON.stringify(payload.schedules || {}))
  if (mediaFile) form.append('media_file', mediaFile)
  const res = await api.post('/orchestrate', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return res.data
}

export async function getHistory() {
  const res = await api.get('/history')
  return res.data
}

export async function getSocialAccounts() {
  const res = await api.get('/social/accounts')
  return res.data
}

export async function disconnectAccount(platform) {
  const res = await api.delete(`/social/${platform}/disconnect`)
  return res.data
}

export function getConnectUrl(platform) {
  return `${API_BASE}/social/${platform}/connect`
}

export async function getPlatforms() {
  const res = await api.get('/platforms')
  return res.data
}

export async function getTrends() {
  const res = await api.get('/trends')
  return res.data
}
